"""执行线类型：把台账中实际使用的七类触发语义抽象为状态机。

这是「纸面推演」的核心构件——每条执行线声明自己的触发语义（收盘确认制 C23
为总原则），由量化腿每周五统一滑动复核，由通用助手逐笔记账。
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class LineKind(str, Enum):
    FIXED = "固定静态线"               # 例：GLDM 85.29（防「移动球门」静态冻结）
    SLIDING_MA = "滑动MA线"            # 例：0700 MA50 444.41 / MA200 494.29（每周五复核）
    PULLBACK_ZONE = "回踩触发制"        # 例：MSFT 513.7-517.5（须回踩进区才触发、禁追）
    LADDER = "阶梯线"                  # 例：SPCX 153 减半/149.9 机械/145.4 全清；MU 三层线
    DUAL_CONFIRM = "双确认"            # 例：GLDM 收≥85.29 且 50MA 走平/回升（同日成立）
    BREAKOUT_CONFIRM = "突破确认制"     # 例：SNOW 放量收 369-370 三日二守
    CLOSE_CONFIRMED = "收盘确认制"      # C23 总原则：以日收盘为准，盘中穿越只发预警
    LIFE_LINE = "生死线"               # 例：BTC 78.6k（贴线追踪，破位计数进红 C）


@dataclass
class ExecutionLine:
    code: str
    name: str
    kind: LineKind
    values: tuple[float, ...]
    note: str = ""
    armed: bool = True                 # 武装中 = 允许纸面触发
    snapshot_date: str | None = None   # 固定值快照存档日（判例①：滑动线固定值须记触发日快照）
    metadata: dict[str, str] = field(default_factory=dict)

    def refresh_moving_average(self, new_values: tuple[float, ...], on_date: str) -> tuple[float, ...]:
        """滑动复核（每周五）：MA 类线刷新为最新滑动值，旧值自动降级为快照存档。

        依据判例①：固定旧值不执行（MU 980/902.6 作废案）。
        """
        if self.kind is not LineKind.SLIDING_MA:
            raise TypeError(f"{self.code}: 仅滑动MA线可滑动复核，{self.kind.value} 请走重新武装流程")
        old = self.values
        self.values = new_values
        self.snapshot_date = on_date
        return old

    def disarm(self, reason: str) -> None:
        """解除武装（如 2359 挂单撤销：右侧 219.2 确认前不入）。"""
        self.armed = False
        self.metadata["disarm_reason"] = reason


# ---------------------------------------------------------------- 台账 v1.1 执行线快照
LINES_20261010: tuple[ExecutionLine, ...] = (
    ExecutionLine("MU.OQ", "美光", LineKind.LADDER, (1077.0, 951.6, 945.7, 673.1),
                  note="1077 回满 / 951.6 减半 / 945.7 存量风险预警（并存不替代） / 673.1 全清"),
    ExecutionLine("GLDM.AM", "黄金迷你ETF", LineKind.DUAL_CONFIRM, (85.29,),
                  note="解禁=收≥85.29 且 50MA 走平/回升（同日成立）＋12 月加息<60%；85.09 旧引作废",
                  metadata={"current_ma50": "85.62", "distance": "-4.2%"}),
    ExecutionLine("MSFT.OQ", "微软", LineKind.PULLBACK_ZONE, (513.7, 517.5),
                  note="二笔回踩进区才触发、禁追（10/9 收 535.07 距区顶 +3.4%）；破 513.7 减半→508.9-509.2 清",
                  metadata={"defense": "513.7 减半 / 508.9-509.2 清", "earnings_cap": "10/29 财报帽 4%"}),
    ExecutionLine("02269.HK", "药明生物", LineKind.PULLBACK_ZONE, (53.0, 53.8),
                  note="G2 限价武装（二选一胜出）；止损带 49.9-51.5 分批 / 46.2 全清"),
    ExecutionLine("02359.HK", "药明康德H", LineKind.PULLBACK_ZONE, (208.0,),
                  note="挂单撤销（裁定⑤）；若存量存在，196 收盘止损令维持", armed=False),
    ExecutionLine("BTC", "比特币", LineKind.LIFE_LINE, (82900.0, 83500.0, 78600.0),
                  note="82.9-83.5k 接位 1% 限价；生死线 78.6k（10/9 现价 82.45k 正贴区下沿 -0.4%）"),
    ExecutionLine("0700.HK", "腾讯控股", LineKind.SLIDING_MA, (444.41, 494.29),
                  note="MA50/MA200 滑动值收编（裁定⑧）；试仓 419-434、止损 411（250 日低）"),
    ExecutionLine("SPCX.OQ", "SpaceX 跟踪标的", LineKind.LADDER, (153.0, 149.9, 145.4),
                  note="153 减半 / 149.9 机械 / 145.4 全清（P-002 减磅令执行中）",
                  metadata={"cap_november": "11 月中余仓压至 ≤4%"}),
    ExecutionLine("SNOW.N", "Snowflake", LineKind.BREAKOUT_CONFIRM, (369.0, 370.0),
                  note="放量收 369-370 三日二守 / 回踩 MA20 336.95 企稳；11 月底财报终裁"),
    ExecutionLine("09988.HK", "阿里巴巴-W", LineKind.FIXED, (115.3,),
                  note="资格线=收复 115.3（≤2%、止 104.2）；冻结带 104.2-110.3 不启用",
                  metadata={"distance": "+7.8%"}),
    ExecutionLine("HPE.N", "慧与", LineKind.CLOSE_CONFIRMED, (62.15,),
                  note="C23 总原则判例（P-006）：假突破降级→收复再确认→首收触发；10/2 首收 65.65",
                  metadata={"lesson": "洗盘摩擦 ~7pp 教训→C24 白名单来源"}),
)
