"""纸面执行台账：全体系唯一执行记账载体（v1.1 终审对齐册的代码化）。

体系性质（重要）：实盘前基建。用户已确认空仓、零实盘执行，历次「执行令」
全部重新定性为纸面推演令。台账纪律：
- 编号 P-序号，终身唯一，作废不删、标注状态
- 通用助手逐笔记账；量化腿供点位核验；首席每周五周检签名；数据腿供数据审计
- 周检对账纳入 G1/G2 验收统计（触发正确率、纪律遵守率、滑点偏差）
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Iterable


class OrderKind(str, Enum):
    CLOSE_ALL = "清仓令"
    REDUCE = "减磅令"
    BAN_BUY = "禁买令"
    FREEZE = "冻结令"
    OPEN = "建仓令"
    LIMIT_ORDER = "挂单令"
    TIME_STOP = "时间止损"
    WAIVER = "豁免条款"


class OrderState(str, Enum):
    PENDING = "待触发"
    TRIGGERED_PAPER = "已触发（纸面）"
    CLOSED = "已关闭"
    VOIDED = "已作废"
    PARTIALLY_REVOKED = "部分撤销"
    SUSPENDED = "挂起中"


@dataclass
class PaperOrder:
    serial: str                      # P-001 … 终身唯一
    issued: str                      # 发布日 YYYY-MM-DD
    kind: OrderKind
    subject: str
    trigger: str                     # 触发条件（收盘确认制口径）
    state: OrderState = OrderState.PENDING
    fill_note: str = ""              # 纸面成交记录
    memo: str = ""                   # 备注（v1.1 对齐）

    def revoke_partially(self, memo: str) -> None:
        """部分撤销（例：P-013 药明系——2359 撤单，2269 维持武装）。"""
        self.state = OrderState.PARTIALLY_REVOKED
        self.memo = f"{self.memo}；{memo}".strip("；")

    def mark_filled(self, fill_note: str) -> None:
        """纸面触发（收盘确认制 C23：以日收盘为准触发后记账）。"""
        assert self.state in (OrderState.PENDING, OrderState.SUSPENDED), "非待触发状态不可触发"
        self.state = OrderState.TRIGGERED_PAPER
        self.fill_note = fill_note


class PaperLedger:
    """唯一记账载体。禁止任何腿在台账之外另设执行记录（判例：单一事实源）。"""

    def __init__(self, version: str = "v1.1") -> None:
        self.version = version
        self._orders: dict[str, PaperOrder] = {}
        self.signatures: list[str] = []          # 周检签名记录

    # -- 登记 / 查询
    def register(self, order: PaperOrder) -> PaperOrder:
        if order.serial in self._orders:
            raise ValueError(f"编号 {order.serial} 已存在：P 序号终身唯一，作废不删只标状态")
        self._orders[order.serial] = order
        return order

    def get(self, serial: str) -> PaperOrder:
        return self._orders[serial]

    def by_state(self, *states: OrderState) -> list[PaperOrder]:
        return [o for o in self._orders.values() if o.state in states]

    # -- 周检
    def weekly_review(self, date: str, reviewer: str = "首席投资策略师") -> str:
        line = f"{date} 周检签名：{reviewer}（{self.version}）"
        self.signatures.append(line)
        return line

    # -- 审计
    def audit(self) -> dict[str, int]:
        return {state.value: len(self.by_state(state)) for state in OrderState}


# ---------------------------------------------------------------- v1.1 真实快照（13 条历史令）
def build_ledger_v1_1() -> PaperLedger:
    """按台账 v1.1《历史纸面令登记》逐条复原。数据对账基准：data/paper_ledger_v1.1_20261010.md。"""
    led = PaperLedger("v1.1")
    rows: Iterable[PaperOrder] = (
        PaperOrder("P-001", "2026-09-19", OrderKind.REDUCE, "SPCX 减仓令（减半）",
                   "9/15 立项→9/18 裁决", OrderState.TRIGGERED_PAPER,
                   "9/19 纸面减 ~50%", "课题 B 证伪链 3/3 兑现"),
        PaperOrder("P-002", "2026-10-05", OrderKind.REDUCE, "SPCX 减磅令",
                   "10/2 收 159.0＋量 1.27×＝R1/R2 双触发", OrderState.TRIGGERED_PAPER,
                   "纸面续减", "减磅带 159.8-160.7 / 165.5-166.2"),
        PaperOrder("P-003", "2026-10-08", OrderKind.TIME_STOP, "SPCX 时间止损",
                   "11 月中压至 ≤4%＋12/9 解禁前清零评估", OrderState.SUSPENDED,
                   "", "12/9=Day180 全额日"),
        PaperOrder("P-004", "2026-09-28", OrderKind.CLOSE_ALL, "ZETA 清仓令",
                   "二守破 29.7", OrderState.TRIGGERED_PAPER,
                   "9/28 开 28.64 纸面清仓", "复盘终判见主报告 §5"),
        PaperOrder("P-005", "2026-09-28", OrderKind.BAN_BUY, "GLDM 黄金链禁买",
                   "9/28 起禁买；解禁=收复 85.29＋50MA 走平/回升（双确认）", OrderState.SUSPENDED,
                   "", "10/14 CPI 裁决沿用 85.29 口径"),
        PaperOrder("P-006", "2026-09-28", OrderKind.WAIVER, "HPE 62.15 双向纪律",
                   "假突破降级→收复再确认→首收触发", OrderState.TRIGGERED_PAPER,
                   "10/2 首收 65.65（当日高 70.29）", "洗盘摩擦 ~7pp 教训→C24 白名单来源"),
        PaperOrder("P-007", "2026-09-26", OrderKind.FREEZE, "港仓冻结令",
                   "港新仓 ≤6%→≤5% 冻结；解冻四条件", OrderState.SUSPENDED,
                   "", "四条件合并 ≈1.5-2/4 未近"),
        PaperOrder("P-008", "2026-10-05", OrderKind.OPEN, "MSFT 通道 B 首笔",
                   "收 525.18＋量 1.25×确认", OrderState.TRIGGERED_PAPER,
                   "10/7 低 524.69 触及、10/8 低 518.79 深入", "二笔改回踩触发制（距区顶 +3.4%）"),
        PaperOrder("P-009", "2026-10-07", OrderKind.OPEN, "CIBR D1 试仓",
                   "放量收 108 纸面试仓；双向（放量加/缩量破 104 撤）", OrderState.TRIGGERED_PAPER,
                   "C1 已触发", "C2 量能未过·C3 三日二守待确认"),
        PaperOrder("P-010", "2026-10-08", OrderKind.LIMIT_ORDER, "BTC 接位挂单",
                   "82.9-83.5k 接位 1%（生死线 78.6k）", OrderState.SUSPENDED,
                   "", "10/9 现价 82.45k 正贴区下沿"),
        PaperOrder("P-011", "2026-10-09", OrderKind.CLOSE_ALL, "SNDK 清仓令",
                   "收 1609.46 < 闸线 1659（-3.0%）＝红 C 第 1 条触发", OrderState.TRIGGERED_PAPER,
                   "", "重站复位语义；10/29 财报前禁加仓"),
        PaperOrder("P-012", "2026-10-08", OrderKind.LIMIT_ORDER, "1816 首注限价",
                   "首注限价单纸面挂出（3.00-3.06）", OrderState.SUSPENDED,
                   "", "双确认已达成；港冻结令辖下"),
        PaperOrder("P-013", "2026-10-08", OrderKind.LIMIT_ORDER, "药明系回踩限价",
                   "02269/02268/02359 G2 区限价", OrderState.PENDING,
                   "", "2359 撤单（裁定⑤）；2269 维持武装 53.0-53.8；2268 走里程碑纪律"),
    )
    for r in rows:
        led.register(r)
    led.get("P-013").revoke_partially("2359 撤销（右侧 219.2 确认前不入）")
    return led
