"""tri_market.execution 子包。"""
