"""协作协议：把团队实际运转中沉淀的 SOP 代码化。

每个协议类对应一套真实运转过的流程，docstring 中附真实案例供评审溯源。
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


# ---------------------------------------------------------------- 标准课题工作流
class WorkflowStage(str, Enum):
    INTAKE = "用户提问"
    DISPATCH = "调度派单（多腿并行·统一口径）"
    LEG_DELIVERY = "各腿交付（报告+发群）"
    L4_VERDICT = "首席 L4 统合终审（分歧仲裁+请裁项裁决）"
    ARCHIVING = "支援层落档三件套"
    RECEIPT_LOOP = "全员回执确认（复核回执制）"
    SILENT_WAIT = "静默建设期（至下一裁决点）"


@dataclass(frozen=True)
class StandardWorkflow:
    """一次标准课题的全链路。

    案例：2026-10-10「三地池子年检」——
    用户 13:08 直问 → 调度 13:10 派单（宏观/量化并行，统一锚=10/9 收盘）→
    两腿 13:26/13:28 交付 → 首席 13:31 终审十项裁定 → 通用助手 13:44 落档三件套 →
    数据腿/宏观腿复核回执，13:45 闭环。
    """

    stages: tuple[WorkflowStage, ...] = field(default_factory=lambda: tuple(WorkflowStage))
    unified_anchor_rule: str = "多腿并行前必须统一：数据锚日期、池口径、输出表格式"
    zero_suspense_rule: str = "首席终审后零无主项、零悬案；分歧必须仲裁或入备查节"

    def next_stage(self, current: WorkflowStage) -> WorkflowStage:
        stages = list(WorkflowStage)
        i = stages.index(current)
        return stages[min(i + 1, len(stages) - 1)]


# ---------------------------------------------------------------- 双源核验
class SourceTier(str, Enum):
    OFFICIAL_FIRSTHAND = "官方一手"       # 官方文件 PDF > 官方新闻稿
    RELIABLE_LEGAL = "法律/权威分析"
    PARTY_STATEMENT = "当事人自述（标 ⚠️ 待确认）"


@dataclass(frozen=True)
class DualSourceVerification:
    """检索→至少两个独立信源交叉核验→摘要归档；✅多源通过 / ⚠️单一信源待确认。

    案例 1（2026-09-27 FTC 诉状）：ftc.gov 起诉状 PDF 直取为最硬核双源素材。
    案例 2（2026-10-10 23×5 课题）：监管时间线以 Federal Register 一手为准，
    媒体层「8/25-26 批准」判定为 SIP/基建层批次口径差——教训：监管时间线
    不以媒体日期为事实锚。
    """

    pass_threshold: int = 2
    mark_pass: str = "✅多源通过"
    mark_single: str = "⚠️单一信源待确认"
    priority: tuple[str, ...] = (
        "官方文件 PDF", "官方新闻稿", "法律分析(JDSupra 类)", "当事人自述(标⚠️)",
    )


# ---------------------------------------------------------------- 装配图改图 SOP
@dataclass(frozen=True)
class AssemblyRevisionSOP:
    """数据/报告装配图的改图四步。

    案例（2026-09-29 Brent 97.44 大勘误）：预定位→首席复裁→随裁落稿→回执清单，
    版本号 v1.x 递进、骨架不动。
    """

    steps: tuple[str, ...] = ("预定位", "首席复裁", "随裁落稿", "回执清单")
    versioning: str = "v1.x 递进；骨架不动，只动口径"


# ---------------------------------------------------------------- 评估双轨制
@dataclass(frozen=True)
class DualTrackEvaluation:
    """开放项收口范式：通道 404 → 备援一次 → 命中值呈 a/b 双轨评估 → 首席裁决 →
    裁决落稿 → 独立 grep 复核回执。

    案例（2026-09-29 JGB 官方 print）：备援命中 1.761 vs 官方 1.692，双轨呈报后
    证伪弃用原稿未采纳值；全史复验把「1996 年 8 月以来最高」水位上修至 3.111（10/7）。
    """

    requires_independent_review: bool = True


# ---------------------------------------------------------------- 回执-吸收-回执
@dataclass(frozen=True)
class ReceiptAbsorptionLoop:
    """协作润滑机制：A 腿交付线索 → B 腿吸收并逐条回执确认 → A 腿确认闭环 → 停止续轮。

    案例（2026-10-10 23×5 课题）：通用助手三条线索被宏观腿 §八全部吸收并回执；
    全栈 v2 清单与量化腿四点技术细节逐点互证后「锁死口径，本线程收工」。
    两轮止损：@ 链路超过两轮无结论即停止互相 @，改由用户拍板。
    """

    max_rounds_between_agents: int = 2
    stop_loss: str = "两轮无结论→@用户请求裁决，禁止第三轮 agent 互@"


# ---------------------------------------------------------------- 数据引用纪律
@dataclass(frozen=True)
class DataReferenceDiscipline:
    """2026-10-10 首席盖章：两腿与终版后续引用一律以《212 只覆盖矩阵 CSV》为准，
    不再零散拉数。配套三判例见 framework/precedents.py。"""

    single_source_of_truth: str = "data/coverage/池子全清单_数据覆盖矩阵_20261010.csv"
