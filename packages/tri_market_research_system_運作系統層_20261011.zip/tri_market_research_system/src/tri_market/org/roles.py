"""组织架构：成员、职责边界与决策权限层级。

设计要点（评审关注）：
1. 用户是唯一 L0 决策者；AI Agent 分为「裁决层 L4」「专业腿 L1-L3」「支援层 L2」。
2. 每个 Agent 有明确的「做/不做」边界（boundary），防止越界判价格行为或判基本面。
3. 全部为纸面推演角色，无实盘交易权限（empty trade_authority）。
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class AuthorityLevel(int, Enum):
    """决策权限层级。数字越大，在该事务上越权威；L0 为人类最终拍板。"""

    L0_USER = 0          # 用户：最终裁决、模式声明（如「空仓纸面推演」）、追认/否决权
    L1_LEG = 1           # 专业腿产出层：宏观基本面 / 量化技术 / 数据管道
    L2_SUPPORT = 2       # 支援层：检索核验、归档、台账记账、索引
    L3_DISPATCH = 3      # 调度层：任务拆解派单、进度收口
    L4_CHIEF = 4         # 首席：分歧仲裁、请裁项终审、执行计划总表唯一口径


class Role(str, Enum):
    USER = "用户"
    DISPATCH = "群管理员/调度"
    CHIEF_STRATEGIST = "首席投资策略师"
    MACRO_RESEARCHER = "宏观基本面研究员"
    QUANT_EXPERT = "资深量化技术专家"
    FULLSTACK_DEV = "全栈开发（数据管道腿）"
    GENERAL_ASSISTANT = "通用助手（支援层）"


@dataclass(frozen=True)
class Member:
    name: Role
    authority: AuthorityLevel
    mission: str
    does: tuple[str, ...]
    boundary: tuple[str, ...] = field(default_factory=tuple)
    trade_authority: str = "无实盘权限；纸面推演口径"

    def __str__(self) -> str:  # pragma: no cover
        return f"{self.name.value}（L{self.authority.value}）"


TEAM_ROSTER: tuple[Member, ...] = (
    Member(
        name=Role.USER,
        authority=AuthorityLevel.L0_USER,
        mission="最终决策者。目标：持续研究中国内地、香港、美国三地市场，关注地缘政治与政策风向、板块轮动。",
        does=(
            "追认/否决框架版本（如 v1.3 否决权开放）",
            "声明体系模式（2026-10-09 确认：空仓、零实盘、模型打磨阶段）",
            "对记帐项升格、模拟启动等拍板",
        ),
        boundary=(),
    ),
    Member(
        name=Role.DISPATCH,
        authority=AuthorityLevel.L3_DISPATCH,
        mission="把用户的开放问题拆解为多腿并行任务，逐腿派单，交付后收口汇报。",
        does=("任务拆解与 @ 派单", "明确各腿边界与统一口径（锚日期/池口径/输出格式）", "成果收口直答用户"),
        boundary=("不做专业研判", "不代替首席终审"),
    ),
    Member(
        name=Role.CHIEF_STRATEGIST,
        authority=AuthorityLevel.L4_CHIEF,
        mission="汇总基本面×技术面，产出融合仓位管理、风险控制与买卖点位的统合终审。",
        does=(
            "两腿分歧仲裁（零悬案原则）",
            "请裁项终审并出具「十项裁定」级裁决",
            "执行计划总表（唯一执行口径）与周检签名（每周五）",
            "框架版本裁决（v1.2 正式收编 → v1.3 十项运行中）",
        ),
        boundary=("不重新拉数（以覆盖矩阵 CSV 为准）", "裁决须可回溯到两腿输入"),
    ),
    Member(
        name=Role.MACRO_RESEARCHER,
        authority=AuthorityLevel.L1_LEG,
        mission="宏观经济、行业政策周期、财报与消息面；基本面四态研判。",
        does=("宏观板块双筛", "基本面留/移/加/禁研判", "事件面增量与制度事实核验（官方一手优先）", "缺口事实核查（双源+时间戳）"),
        boundary=("不判价格行为/执行线（技术腿管辖）", "拉数必核 52 周高区间与代码映射（XOM 误标记忆）"),
    ),
    Member(
        name=Role.QUANT_EXPERT,
        authority=AuthorityLevel.L1_LEG,
        mission="行情深度挖掘与量化模型：K 线形态、均线系统、量价关系、支撑阻力、执行线状态。",
        does=("监控总表全量重算（68 只×260 根）", "技术面四态扫描", "MA 类线滑动复核（每周五统一刷新）", "假突破判别规则（P0）"),
        boundary=("不判基本面", "线值刷新须回写台账"),
    ),
    Member(
        name=Role.FULLSTACK_DEV,
        authority=AuthorityLevel.L1_LEG,
        mission="数据管道腿：三地行情抓取、调度守护、数据底座与口径校验。",
        does=("market_fetcher 三地行情管道", "调度守护（ah_eod/us_morning + 守护进程自愈）", "覆盖矩阵维护（212 只×250 根）", "23×5 新制的 16:00 收盘锚等工程适配"),
        boundary=("只做数据层，不判多空", "数据口径变更须两腿复核"),
    ),
    Member(
        name=Role.GENERAL_ASSISTANT,
        authority=AuthorityLevel.L2_SUPPORT,
        mission="支援层：中英文检索与双源核验、会议纪要、归档落盘、台账记账、索引卡与汇总卡。",
        does=("独立双源事实核验（给各腿供线索）", "落档三件套：终版归档 + 观察清单主档滚动 + 台账归位记账", "缺口/跟进事项总清单盘点", "文件索引与预留位管理"),
        boundary=("专业结论以三位专家为准", "并发协作前先扫 shared/ 最新文件（对齐锚教训）"),
    ),
)


def find(role: Role) -> Member:
    """按角色查成员。"""
    for m in TEAM_ROSTER:
        if m.name is role:
            return m
    raise KeyError(role)
