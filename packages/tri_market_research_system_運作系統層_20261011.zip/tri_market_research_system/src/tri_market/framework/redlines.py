"""红 A / 红 B / 红 C：系统性风险三级预警线。

红 A＝指数级无条件砍半线；红 B＝利率红线；红 C＝标的生死线破位计数器（1/3 触发即执行）。
快照口径 = 2026-10-09/10 台账与复盘。
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class RedlineKind(str, Enum):
    A_INDEX = "红A·指数级"
    B_RATE = "红B·利率级"
    C_LIFELINE = "红C·生死线计数"


@dataclass(frozen=True)
class Redline:
    kind: RedlineKind
    description: str
    action: str
    status_20261010: str


REDLINES_20261010: tuple[Redline, ...] = (
    Redline(
        RedlineKind.A_INDEX,
        "SPY 748.8 无条件砍半线（改判须首席明示）",
        "收盘破线 → 全仓无条件砍半，无豁免条款",
        "10/10 缓冲 +3.35%，未触发",
    ),
    Redline(
        RedlineKind.B_RATE,
        "US 10Y 5.28%（红线 B）；三闸 5.30%（全面进攻第二闸之一）",
        "贴线缓解观察；10Y 三日 >5.30 = 双闸之一达成",
        "5.28 临界缓解",
    ),
    Redline(
        RedlineKind.C_LIFELINE,
        "红 C 生死线计数：任一标的收盘破其生死线计 1/3",
        "1/3 触发即按纪律执行该标的清仓/减半；不等待 2/3",
        "SNDK 收 1609.46 < 1659 = 红 C 1/3 已触发（P-011 清仓令）",
    ),
)


@dataclass
class LifelineCounter:
    """红 C 计数器：生死线破位追踪。

    已知生死线样本：SNDK 1659 / BTC 78.6k / HSTECH 4111.32（预警）/ 沪深300 60日低（总闸预警）。
    """

    thresholds: dict[str, float] = field(default_factory=dict)
    breached: list[str] = field(default_factory=list)

    def register(self, code: str, lifeline: float) -> None:
        self.thresholds[code] = lifeline

    def check(self, code: str, close: float) -> bool:
        """收盘确认制（C23）：以日收盘为准，盘中穿越只发预警。返回是否新触发。"""
        line = self.thresholds.get(code)
        if line is None:
            return False
        if close < line and code not in self.breached:
            self.breached.append(code)
            return True
        return False

    @property
    def fraction(self) -> str:
        total = max(len(self.thresholds), 1)
        return f"{len(self.breached)}/{total}"
