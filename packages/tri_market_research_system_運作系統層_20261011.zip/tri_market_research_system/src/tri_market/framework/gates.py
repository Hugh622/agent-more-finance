"""四闸仓位系统：全部仓位帽与「先减后加」纪律。

体系核心安全机制之一：任何新开仓前先查四闸；闸满 = 零自由加仓，
新仓必须「先减后加」。以下数字为 2026-10-10 台账 v1.1 快照（纸面推演口径）。
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class GateName(str, Enum):
    SINGLE_STOCK = "个股闸"
    THEMATIC = "主题闸"
    CRYPTO = "加密闸"
    TOTAL = "总闸"


@dataclass(frozen=True)
class Gate:
    name: GateName
    used: int
    capacity: int

    @property
    def free(self) -> int:
        return max(self.capacity - self.used, 0)

    @property
    def is_full(self) -> bool:
        return self.free == 0


#: 2026-10-10 台账快照：四闸近满 → 零自由加仓空间
GATES_SNAPSHOT_20261010: tuple[Gate, ...] = (
    Gate(GateName.SINGLE_STOCK, used=25, capacity=28),
    Gate(GateName.THEMATIC, used=11, capacity=12),
    Gate(GateName.CRYPTO, used=4, capacity=4),
    Gate(GateName.TOTAL, used=33, capacity=36),
)


@dataclass(frozen=True)
class GateVerdict:
    allowed_without_reduction: bool
    reason: str
    blocked_by: tuple[GateName, ...]


def can_open_new_position(
    gates: tuple[Gate, ...] = GATES_SNAPSHOT_20261010,
) -> GateVerdict:
    """开新仓裁决：任一闸满、或仅余 1 格 → BLOCK（先减后加）。

    「减出额度是安全垫不是弹药」——free≤1 与 full 同判：
    接近满闸时新仓会让板块集中度失控。
    """
    blocked = tuple(g.name for g in gates if g.is_full or g.free <= 1)
    if blocked:
        return GateVerdict(
            allowed_without_reduction=False,
            reason="闸满或仅余 1 格＝零自由加仓；新仓一律先减后加，减出额度是安全垫不是弹药",
            blocked_by=blocked,
        )
    return GateVerdict(True, "存在自由额度", ())


#: 仓位帽（仓位上限章程）。paper 笔记：以台账 v1.1 执行计划总表逐行引用为准。
POSITION_CAPS: dict[str, str] = {
    "港股单标的": "≤7%",
    "港仓新仓（冻结期）": "≤5%（P-007 冻结令辖下）",
    "试仓": "≤2%",
    "主题（如网安 C17）": "≤12%",
    "个股财报窗帽（如 MSFT 10/29）": "4%",
    "SPCX 余仓（11 月中）": "≤4%（P-002 减磅令执行中）",
    "加密": "4/4 满＝先减后加",
}

#: 典型禁令（红名单节选，完整 14 卡见终审 HTML）
RED_LIST_EXCERPTS: tuple[str, ...] = (
    "黄金链禁买（GLDM 解禁=收≥85.29 且 50MA 走平/回升＋12 月加息<60% 三条件）",
    "中概左侧接刀（9988 未收复 115.3、0700 未收复 502.4 语境冻结）",
    "TLN/NRG/SMR 禁碰；86-87k 追 BTC 禁止",
    "10/27-29 FOMC＋四财报窗：只减不加",
    "AVGO/UNH/GDX/XBI 回避名单",
)
