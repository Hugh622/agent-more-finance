"""四态研判与观察池分层：留观 / 移出 / 加 / 禁碰，配 A/B/C 三层与短中长期限。

快照数据 = 2026-10-10《三地池子年检·首席统合终审》（总基调：留而不进·等闸开·动池子不动钱）。
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class FourState(str, Enum):
    KEEP = "留观"       # 留在池内继续观察
    REMOVE = "移出"     # 移出观察池
    ADD = "加"          # 新增入池
    BAN = "禁碰"        # 红名单，禁止新建任何敞口


class Horizon(str, Enum):
    SHORT = "短"        # 右侧执行
    MID = "中"          # 条件格
    LONG = "长"         # 发展锚 + 烈度封顶


class PoolTier(str, Enum):
    """观察池三层（覆盖矩阵「年检归属」列同源）。"""

    A_CORE = "A核心"        # 核心层：逐一评，带执行线
    B_SATELLITE = "B卫星"   # 卫星层：按主题批量评
    C_TRACK = "C跟踪"       # 跟踪/禁/出池
    INFRA = "基础设施池"     # 指数/总闸/背景数据


@dataclass(frozen=True)
class Verdict:
    code: str
    name: str
    state: FourState
    horizon: Horizon | None = None
    tier: PoolTier | None = None
    rationale: str = ""


#: 2026-10-10 年检代表性裁定样本（完整 68 只见 data/pool_review/ 终审 HTML）
REVIEW_20261010_SAMPLES: tuple[Verdict, ...] = (
    Verdict("02269", "药明生物", FourState.KEEP, Horizon.SHORT, PoolTier.A_CORE,
            "药明二选一胜出：生物药 CDMO 纯度＋执行线三层结构完整；G2 限价 53.0-53.8 武装"),
    Verdict("02359", "药明康德H", FourState.REMOVE, rationale="止损 196 距 -5.8% 风险不对称，G2 已全触；右侧 219.2 确认前不入"),
    Verdict("QS", "QuantumScape", FourState.REMOVE, rationale="固态时间表持续后移、无事件锚——超长线「无催化让位」纪律"),
    Verdict("BMNR", "Bitmine Immersion", FourState.REMOVE, rationale="破止损 24.70（收 24.03）＋趋势坏；撤单移出，不重挂"),
    Verdict("SNOW", "Snowflake", FourState.KEEP, Horizon.SHORT, rationale="移出暂缓→突破确认制留观：放量收 369-370 三日二守；11 月底财报终裁"),
    Verdict("XOM", "埃克森美孚", FourState.KEEP, rationale="回踩 MA20 163.50 口径（RSI 81.4 禁追）；199.6-211 区带实为 CVX（判例③）"),
    Verdict("688561", "奇安信", FourState.KEEP, Horizon.SHORT, rationale="Y3 验证窗 10/9-10/23：上确认 31.88 放量 / 下预警 28.28"),
    Verdict("GLDM", "黄金迷你ETF", FourState.BAN, rationale="禁买维持：距解禁线 85.29 -4.2%，三条件全缺"),
    Verdict("ZETA", "Zeta Global", FourState.BAN, rationale="清仓后复活观察窗（不回补）；翻案只走新仓流程"),
    Verdict("JPM", "摩根大通", FourState.REMOVE, rationale="自然出池；条件化复议动议备查（鹰派落地或 10Y 三日>5.30 仅议 JPM）"),
)

#: 网安 A 股轮换制（裁定⑦）：同源逻辑勿假分散
CYBERSEC_ROTATION_20261010: dict[str, str] = {
    "688561 奇安信": "优先（Y3 窗在跑已武装）",
    "688023 安恒信息": "备选轮换 1（回踩限价资格保留至 10 月底）",
    "300454 深信服": "备选轮换 2",
    "002439 启明星辰": "备选轮换 3",
}
CYBERSEC_RULE = "四只不同时入场；主题 ≤12% 帽不变；裁决点前零强制敞口"

#: 年检总盘点
REVIEW_20261010_SUMMARY: dict[str, int] = {
    "留观": 23, "移出": 20, "移出候审": 3, "加": 0, "红名单卡": 14,
}
