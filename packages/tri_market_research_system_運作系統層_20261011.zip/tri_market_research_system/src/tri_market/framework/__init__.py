"""tri_market.framework 子包。"""
