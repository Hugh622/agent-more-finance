"""tri_market.quant_leg 子包。"""
