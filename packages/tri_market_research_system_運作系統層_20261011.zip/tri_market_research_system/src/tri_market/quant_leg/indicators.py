"""轻量技术指标（纯标准库实现）——量化腿核心语义的最小可运行版本。

完整实现见 tools/kline_diag/（量化工具 v1 源码快照）。
本模块仅收录「执行线语义」直接依赖的部分，供测试与教学。
"""
from __future__ import annotations

from typing import Sequence


def sma(closes: Sequence[float], window: int) -> float | None:
    """简单均线。数据不足返回 None（不外推、不编数）。"""
    if len(closes) < window:
        return None
    return sum(closes[-window:]) / window


def rsi(closes: Sequence[float], window: int = 14) -> float | None:
    """Wilder RSI。"""
    if len(closes) < window + 1:
        return None
    gains = losses = 0.0
    for i in range(1, window + 1):
        chg = closes[-i] - closes[-i - 1]
        gains += max(chg, 0.0)
        losses += max(-chg, 0.0)
    if losses == 0:
        return 100.0
    rs = (gains / window) / (losses / window)
    return 100 - 100 / (1 + rs)


def volume_ratio(volumes: Sequence[float], snapshot: float, window: int = 5) -> float | None:
    """量比 = 当前量 / 前 N 日均量（与快照口径一致）。"""
    if len(volumes) < window or snapshot <= 0:
        return None
    avg = sum(volumes[-window:]) / window
    return snapshot / avg if avg > 0 else None


def breakout_two_of_three(
    closes: Sequence[float], threshold_low: float, threshold_high: float
) -> dict[str, object]:
    """突破确认制（SNOW 语义）：放量收 369-370 三日二守——

    最近 3 根收盘价中 ≥2 根落在 [threshold_low, threshold_high] 即确认。
    返回 {"confirmed": bool, "hits": int, "window": [c-2, c-1, c]}。
    """
    window = list(closes[-3:])
    hits = sum(threshold_low <= c <= threshold_high for c in window)
    return {"confirmed": hits >= 2, "hits": hits, "window": window}


def pullback_zone_check(
    close: float, zone_low: float, zone_high: float, forbid_chase_margin: float = 0.0
) -> dict[str, object]:
    """回踩触发制（MSFT 语义）：现价须回踩进区才触发、禁追。

    返回触发/禁追判定与距区顶百分比（+ = 高于区顶）。
    """
    above_top_pct = (close / zone_high - 1) * 100
    in_zone = zone_low <= close <= zone_high
    return {
        "in_zone": in_zone,
        "above_top_pct": round(above_top_pct, 2),
        "verdict": (
            "触发" if in_zone
            else ("禁追·等回踩" if above_top_pct > 0 else "低于区间·重新评估")
        ),
        "note": "禁追（距区顶 +3.4% 语境）" if above_top_pct > forbid_chase_margin else "",
    }


def friday_sliding_review(
    closes: Sequence[float], ma_windows: Sequence[int] = (50, 200)
) -> dict[int, float | None]:
    """周五滑动复核（判例①）：返回各 MA 窗口的最新滑动值。

    口径：MA 类执行线一律滑动复核制，固定值仅作触发日快照存档。
    """
    return {w: sma(closes, w) for w in ma_windows}
