"""研究档案库分类法：00-09 目录、四套模板与文档命名规范。

档案库是全体系的「长期记忆」：所有报告/纪要/裁定按分类落盘，配合
「先扫 shared/ 最新文件再定稿」的并发协作纪律（对齐锚教训）。
"""
from __future__ import annotations

from datetime import date

#: 一级目录（2026-10 新增 09_组合策略 与 09_人物事實檔）
ARCHIVE_TAXONOMY: dict[str, str] = {
    "00_模板": "四套标准模板（每日简报/公司卡片/行业卡片/会议纪要）",
    "01_每日简报": "每日简报（固定「地缘政治与政策风向」栏目：政策→资金→资产）",
    "02_会议纪要": "周复盘/专题纪要（如粤语周复盘）",
    "03_公司研究": "个股深度（含美股/港股/A股子目录）",
    "04_行业研究": "行业卡片与专题",
    "05_宏观与政策": "宏观数据、政策核验（如 23×5 制度核验）",
    "06_地缘政治": "地缘事件追踪",
    "07_数据与图表": "图表资产与数据快照",
    "08_归档": "过期/冻结文档存档（v1.0 台账冻结件等）",
    "09_组合策略": "池子年检/执行台账/观察清单/终审四件链",
    "09_人物事實檔": "人物事实档案（双源核验）",
}

#: 四套模板
TEMPLATES: tuple[str, ...] = (
    "每日简报模板", "公司卡片模板", "行业卡片模板", "会议纪要模板",
)


def doc_name(topic: str, author: str, on: date, prefix: str = "") -> str:
    """文档命名规范：{前缀}{主题}_{作者}_{YYYYMMDD}。

    交付类文档带作者与日期，保证多腿并行时可溯源、可对账。
    """
    stem = f"{prefix}{topic}_{author}_{on:%Y%m%d}" if author else f"{prefix}{topic}_{on:%Y%m%d}"
    return stem


def verify_no_duplicates(names: list[str]) -> list[str]:
    """并发协作纪律：落档前先扫 shared/ 最新文件，避免重复交付（对齐锚教训）。"""
    seen: dict[str, str] = {}
    dups: list[str] = []
    for n in names:
        key = n.split("_")[0]
        if key in seen and n != seen[key]:
            dups.append(f"{n} 与 {seen[key]} 主题重复")
        else:
            seen[key] = n
    return dups
