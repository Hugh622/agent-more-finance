"""tri_market.data_leg 子包。"""
