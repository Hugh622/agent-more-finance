"""数据管道契约：来源等级、降级链与已知缺口（透明清单）。

等级口径（对齐《官方数据第三方可靠来源清单与核验标准 v1》）：
L1 官方直连 → L2 第三方可靠来源（白名单核验；行情类=授权行情商）→ L3 检索兜底。
所有输出强制带 fetched_at + source(机构-媒体-时间戳) + source_level 字段。
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class Level(str, Enum):
    L1_OFFICIAL = "L1·官方直连"
    L2_RELIABLE = "L2·第三方可靠"
    L3_FALLBACK = "L3·检索兜底"


class ChannelState(str, Enum):
    ACTIVE = "在用"
    DOWN = "不可达"
    BLOCKED = "环境出口屏蔽"
    PROXY_PENDING = "待启用（key/proxy 就绪）"


@dataclass(frozen=True)
class Channel:
    name: str
    level: Level
    state: ChannelState = ChannelState.ACTIVE
    note: str = ""


#: 通道注册表（2026-10-10 实测状态）
CHANNELS: tuple[Channel, ...] = (
    Channel("SEC EDGAR", Level.L1_OFFICIAL, note="规范 UA＋官方 CIK 表；10-K/10-Q/8-K 直连"),
    Channel("美国财政部官网", Level.L1_OFFICIAL, note="美债 2Y/10Y/30Y 收益率主源"),
    Channel("FRED", Level.L1_OFFICIAL, note="DFF/VIXCLS/DGS 系列官方收盘"),
    Channel("日本财务省（英文路径）", Level.L1_OFFICIAL, note="JGB 官方 print；中文路径 404 走英文备援"),
    Channel("Federal Register", Level.L1_OFFICIAL, note="监管批准链一手锚（判例⑥）"),
    Channel("腾讯授权行情通道", Level.L2_RELIABLE, note="3 域名轮转故障转移；A/HK/指数/美股兜底"),
    Channel("Finnhub", Level.L2_RELIABLE, ChannelState.PROXY_PENDING,
            note="美股主力源待启用：60/min 滑窗限流；本环境 Cloudflare 托管域 TCP 不可达"),
    Channel("AASTOCKS / etnet / stockanalysis / GoogleFinance / 网易", Level.L3_FALLBACK, ChannelState.DOWN,
            note="实测不可用（CF 盾/超时/DNS 败），不采用"),
    Channel("stooq / 东财 / Yahoo", Level.L3_FALLBACK, ChannelState.DOWN, note="JS 挑战/不可达"),
)

#: 降级链（依次尝试）
DEGRADE_CHAINS: dict[str, tuple[str, ...]] = {
    "三地日K线": ("腾讯 web.ifzq.gtimg.cn", "腾讯 ifzq.gtimg.cn", "腾讯 proxy.finance.qq.com",
               "美股指数 fqkline 不足→usfqkline 端点自动降级"),
    "美债收益率": ("财政部官网", "FRED DGS2/10/30", "L2 登记簿录入"),
    "VIX": ("FRED VIXCLS 官方收盘",),
    "SEC 财报": ("EDGAR 官方直连",),
    "JGB": ("财务省中文路径", "英文路径备援一次", "a/b 双轨评估→首席裁决"),
    "USDCNH": ("腾讯无通道→USDCNY 在岸近似", "L2 检索"),
    "南向资金": ("腾讯/东财均不可达", "L2 检索：智通/AASTOCKS，A+B 双源"),
    "人民币中间价": ("无稳定通道", "L2 检索：外汇局 9:15 通稿，登记簿录入"),
}

#: 抓取铁律（v1.0 铁律三扩列至九条，节选与机器相关项）
FETCH_RULES: tuple[str, ...] = (
    "K线 param 必须为 '{code},day,,,{count},qfq'（count 第 4 段，日期留空）",
    "美股后缀严格区分交易所：NASDAQ→.OQ、NYSE→.N、ETF(Arca/AMEX)→.AM",
    "批次请求间隔 ≥2 秒；首轮失败>0 原样重跑即可（限流恢复）",
    "无效/退市标的返回 v_pv_none_match → fetch_kline 返回 None，批次不中断",
    "原始行序 [date,open,close,high,low,volume] 落盘重排为标准 OHLCV；amount_raw 未归一，跨市场比较一律用比率",
    "量比栏位：港股快照 f50、A股快照 f49（量比=昨量/前5日均量口径）",
    "美股行情接口 param 拼法 '{code},day,,,{count}）；港股/美股独立第二源=finance.yahoo.com 报价页",
)

#: 调度窗口（北京时间）
SCHEDULE: tuple[tuple[str, str, str], ...] = (
    ("周一~周五 16:40", "ah_eod", "A/H 收盘后全量：三地 K 线 250 根＋快照＋宏观 P0"),
    ("周二~周六 06:30", "us_morning", "美股收盘后：美股段 K 线＋快照＋宏观 P0"),
    ("周一 06:30", "us_morning 轻量", "美股无新收盘，仅快照＋宏观；周日跳过"),
)

#: 已知残余缺口（与终版假设一致，不阻塞）
KNOWN_GAPS: tuple[str, ...] = (
    "BTC 自源口径（当前引用第三方报价）",
    "南向资金 L2 双源录入",
    "IGV 周一 06:30 自愈（当前 250 根中仅 1 行）",
    "中债 CFETS 逆向（v2）",
    "Finnhub 端点级实测矩阵（出口恢复后跑 finnhub_verify.py）",
)
