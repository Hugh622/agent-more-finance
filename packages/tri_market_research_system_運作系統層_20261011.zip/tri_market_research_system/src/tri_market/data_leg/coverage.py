"""覆盖矩阵：全体系数据引用的单一事实源（首席 2026-10-10 盖章）。

CSV：212 只标的 × 层级/代码/最新收盘/K线行数/年检归属。
本模块提供加载、过滤与「年检就绪」校验（K 线行数、美股后缀规范）。
"""
from __future__ import annotations

import csv
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

DEFAULT_CSV = Path(__file__).resolve().parents[3] / "data" / "coverage" / "池子全清单_数据覆盖矩阵_20261010.csv"

VALID_US_SUFFIXES = (".OQ", ".N", ".AM")   # NASDAQ / NYSE / ETF(Arca/AMEX)


@dataclass(frozen=True)
class CoverageRow:
    tier: str          # 层级/池：指数、A股65、港股24、美股池(映射表)、ETF、研究池新增…、网安A股轮换
    code: str          # 如 sh600036 / hk00700 / usMSFT.OQ
    name: str
    last_date: str
    last_close: float
    rows: int          # K 线行数
    annual_review_tier: str   # 年检归属：A核心/B-xx/C-跟踪/基础设施池/指数总闸…
    note: str = ""


class CoverageMatrix:
    def __init__(self, rows: list[CoverageRow], source_path: Path | None = None) -> None:
        self.rows = rows
        self.source_path = source_path

    # ------------------------------------------------------------- 构造
    @classmethod
    def load(cls, path: Path | str = DEFAULT_CSV) -> "CoverageMatrix":
        path = Path(path)
        with path.open(encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            rows = [
                CoverageRow(
                    tier=(r.get("层级/池") or r.get("\ufeff层级/池") or "").strip(),
                    code=r["代码"].strip(),
                    name=r["名称"].strip(),
                    last_date=r["最新日K"].strip(),
                    last_close=float(r["最新收盘"]),
                    rows=int(r["K线行数"]),
                    annual_review_tier=r["年检归属"].strip(),
                    note=(r.get("数据备注") or "").strip(),
                )
                for r in reader
            ]
        return cls(rows, path)

    # ------------------------------------------------------------- 查询
    def by_tier(self, tier_prefix: str) -> list[CoverageRow]:
        return [r for r in self.rows if r.tier.startswith(tier_prefix)]

    def by_review_tier(self, prefix: str) -> list[CoverageRow]:
        """按年检归属前缀过滤，如 'A核心'。"""
        return [r for r in self.rows if r.annual_review_tier.startswith(prefix)]

    def find(self, code: str) -> CoverageRow:
        for r in self.rows:
            if r.code == code:
                return r
        raise KeyError(code)

    # ------------------------------------------------------------- 校验
    def stats(self) -> dict[str, int]:
        out: dict[str, int] = {"total": len(self.rows)}
        for r in self.rows:
            out[r.tier] = out.get(r.tier, 0) + 1
        return out

    def suffix_violations(self) -> list[CoverageRow]:
        """美股代码后缀必须严格区分交易所（集成约定②）。

        豁免：指数行（tier=「指数」）——usDJI/usIXIC/usINX/usNDX 为指数代码，
        无单一只个股交所后缀，属规范内写法。
        """
        return [
            r for r in self.rows
            if r.code.startswith("us")
            and r.tier != "指数"
            and not r.code.endswith(VALID_US_SUFFIXES)
        ]

    def thin_history(self, min_rows: int = 250) -> list[CoverageRow]:
        """历史不足标的（年检口径：250 根为标准；251 允许；1 行=已知缺口如 IGV）。"""
        return [r for r in self.rows if r.rows < min_rows]

    def annual_check_report(self) -> str:
        thin = {r.code for r in self.thin_history()}
        viol = {r.code for r in self.suffix_violations()}
        return (
            f"覆盖矩阵 {len(self.rows)} 只｜K线不足 250 根：{sorted(thin) or '无'}｜"
            f"美股后缀违规：{sorted(viol) or '无'}｜"
            f"年检就绪率 {(1 - len(thin) / len(self.rows)):.1%}"
        )


def iter_codes(matrix: CoverageMatrix, review_tiers: Iterable[str]) -> list[str]:
    """按年检归属取代码清单（供批量抓取与诊断复用）。"""
    tiers = set(review_tiers)
    return [r.code for r in matrix.rows if r.annual_review_tier in tiers]
