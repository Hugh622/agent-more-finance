"""裁决节点日历：2026Q4 → 2027Q1 全节点 + 每节点的预写动作。

设计特点：每个事件自带 `actions`（预写动作）与 `owner`——日历不是提醒表，
而是「到点即执行预案」的挂载点。23×5 生效日采用 T-0 滑动锚（「不早于 12/6」）。
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class EventKind(str, Enum):
    MACRO_DATA = "宏观数据"
    CENTRAL_BANK = "央行/利率"
    EARNINGS = "财报"
    WEEKLY_CHECK = "周检"
    SLIDING_REVIEW = "MA滑动复核"
    REGIME_CHANGE = "制度切换"
    ACCEPTANCE = "验收节点"
    DATA_RELEASE = "数据发布"
    POLICY = "政策会议"
    CORPORATE = "公司事件"


@dataclass(frozen=True)
class Event:
    date: str            # YYYY-MM-DD（滑动锚以 note 说明）
    name: str
    kind: EventKind
    actions: tuple[str, ...] = field(default_factory=tuple)
    owner: str = "首席投资策略师"

    def __str__(self) -> str:  # pragma: no cover
        return f"{self.date} {self.name}"


EVENTS: tuple[Event, ...] = (
    Event("2026-10-12", "W0 模拟周期起跑", EventKind.ACCEPTANCE,
          ("纸面推演周期从本日起算", "G2=12/18-20 五闸验收的起点对齐"), owner="全体系"),
    Event("2026-10-13", "周检挂单确认", EventKind.WEEKLY_CHECK,
          ("601985 复议结案回执（黄灯归档倾向）", "挂单全量核对", "银行股财报作循环融资叙事法庭证据"),
          owner="首席投资策略师"),
    Event("2026-10-14", "美国 9 月 CPI 公布", EventKind.MACRO_DATA,
          ("GLDM 解禁双条件裁决：收≥85.29 且 50MA 走平/回升（同日成立）", "12 月加息概率 <60% 双确认核验",
           "10Y 三闸 5.30 对照", "85.09 旧口径作废确认"), owner="首席投资策略师"),
    Event("2026-10-15", "台积电法说", EventKind.EARNINGS,
          ("MU 1077 回满线 / SOXX 575.69 预授信第二触发源核验", "AI 循环融资叙事产业链口径对账"),
          owner="资深量化技术专家"),
    Event("2026-10-16", "首次周五滑动复核＋周检", EventKind.SLIDING_REVIEW,
          ("台账 v2 正式收编（十项预收编清单）", "0700/MU 及全部 MA 执行线由量化腿统一刷新",
           "SPCX 阶梯滑动复核", "奇安信首读入册"), owner="资深量化技术专家＋通用助手"),
    Event("2026-10-23", "奇安信 Y3 升格窗截止", EventKind.ACCEPTANCE,
          ("上确认 31.88 放量 / 下预警 28.28 核对", "网安轮换制是否滚动至备选 1"), owner="资深量化技术专家"),
    Event("2026-10-24", "ESMO 大会（MRNA LBA1）", EventKind.CORPORATE,
          ("MRNA 叙事增量评估", "创新药/mRNA 主题池对账"), owner="宏观基本面研究员"),
    Event("2026-10-26", "五中全会（10/26-29）", EventKind.POLICY,
          ("十五五规划窗口叙事跟踪", "党建议程：勿抢跑、勿自行解读为落地政策"),
          owner="宏观基本面研究员"),
    Event("2026-10-27", "FOMC＋四财报窗（10/27-29）", EventKind.CENTRAL_BANK,
          ("MSFT/META/NOW/SNDK 财报——只减不加窗", "MSFT 财报帽 4% 核对", "NOW 340-360 区间预写动作"),
          owner="首席投资策略师"),
    Event("2026-11-03", "美国中期选举", EventKind.POLICY, ("波动预案对账",), owner="宏观基本面研究员"),
    Event("2026-11-04", "ZETA 财报（ACV 证据）", EventKind.EARNINGS,
          ("复活观察窗：ACV 增速+利润率证据→重评 ≤1.5% 新仓流程（不回补）"), owner="宏观基本面研究员"),
    Event("2026-11-10", "休战窗口到期", EventKind.POLICY, ("地缘叙事对账",), owner="宏观基本面研究员"),
    Event("2026-11-14", "康方生物 PDUFA", EventKind.CORPORATE, ("09926 叙事节点对账",), owner="宏观基本面研究员"),
    Event("2026-11-15", "10 月复盘（月中）", EventKind.ACCEPTANCE,
          ("复活名单升格正式提案", "G1 触发正确率/纪律遵守率/滑点偏差统计"), owner="首席投资策略师"),
    Event("2026-11-30", "SNOW 财报终裁", EventKind.EARNINGS, ("突破确认制留观到期裁决",), owner="首席投资策略师"),
    Event("2026-12-05", "23×5 新制三作业建成＋单测", EventKind.REGIME_CHANGE,
          ("05:05 隔夜锚拉 / 10:00 收盘捕手 / T-0 存档核验", "全栈自测报告"), owner="全栈开发"),
    Event("2026-12-06", "美股 23×5 延长交易生效（T-0 滑动锚）", EventKind.REGIME_CHANGE,
          ("生效日前一周 NYSE 官方公告终核（协议第 0 条）", "「不早于 12/6」滑动锚解包",
           "止损三层化预案武装：外层结构线/中层隔夜滑点带/内层夜盘禁市价"), owner="全栈开发＋首席"),
    Event("2026-12-07", "首个隔夜交易段", EventKind.DATA_RELEASE,
          ("首日数据回填（10:00 HKT 后）", "量能基线 12/7 起 20 日重算", "缺口定义重写：真跳空=越隔夜段高低"),
          owner="全栈开发"),
    Event("2026-12-08", "三源 bar 口径校准报告（12/8-9）＋FOMC", EventKind.CENTRAL_BANK,
          ("腾讯/官方/Finnhub 三源校准", "12 月 FOMC 加息概率终核（GLDM 第三条件）"), owner="全栈开发＋首席"),
    Event("2026-12-09", "SPCX 解禁前清零评估", EventKind.ACCEPTANCE,
          ("Day180 全额解禁日评估（P-003）", "官方分级解禁表核对"), owner="首席投资策略师"),
    Event("2026-12-16", "TIC 8 月数据发布", EventKind.DATA_RELEASE,
          ("「聪明钱在买什么」F 节对账",), owner="宏观基本面研究员"),
    Event("2026-12-18", "G2 五闸验收（12/18-20）", EventKind.ACCEPTANCE,
          ("五闸全过=W0 系统正式达验收", "触发正确率/纪律遵守率/滑点偏差三指标裁决",
           "通过才谈正式执行；不通过继续纸面打磨"), owner="首席投资策略师＋全体系"),
    Event("2026-12-20", "美光 FQ1 财报（12 月中）", EventKind.EARNINGS,
          ("GM 再降→951.6 减半 / 673.1 全清机械执行（无新裁决不豁免）"), owner="资深量化技术专家"),
    Event("2027-01-10", "中美休战节点", EventKind.POLICY, ("叙事日历对账",), owner="宏观基本面研究员"),
    Event("2027-03-14", "美夏令切换＝23×5 满血联动", EventKind.REGIME_CHANGE,
          ("监控钟移位 10:00→09:00、05:00→04:00", "调度守护夏令适配验证"), owner="全栈开发"),
)


def upcoming(after: str) -> list[Event]:
    """after（YYYY-MM-DD）之后的节点，按日期升序。"""
    return sorted((e for e in EVENTS if e.date > after), key=lambda e: e.date)


def on(date: str) -> list[Event]:
    return [e for e in EVENTS if e.date == date]
