"""纸面执行台账模型对账测试：13 条历史令 + 台账纪律（v1.1 口径）。"""
import pytest

from tri_market.execution.ledger import (
    OrderKind,
    OrderState,
    PaperLedger,
    PaperOrder,
    build_ledger_v1_1,
)


@pytest.fixture()
def ledger() -> PaperLedger:
    return build_ledger_v1_1()


def test_thirteen_paper_orders_registered(ledger: PaperLedger):
    audit = ledger.audit()
    assert sum(audit.values()) == 13
    # 状态分布（以 data/paper_ledger_v1.1_20261010.md §二逐条对账）：
    # 纸面已触发 P-001/002/004/006/008/009/011 = 7；挂起 P-003/005/007/010/012 = 5；
    # P-013 经裁定⑤部分撤销 = 1
    assert audit[OrderState.TRIGGERED_PAPER.value] == 7
    assert audit[OrderState.SUSPENDED.value] == 5
    assert audit[OrderState.PARTIALLY_REVOKED.value] == 1
    assert audit[OrderState.PENDING.value] == 0


def test_state_distribution_v11(ledger: PaperLedger):
    """逐条状态复原（以 data/paper_ledger_v1.1 §二为基准）。"""
    expect = {
        "P-001": OrderState.TRIGGERED_PAPER, "P-002": OrderState.TRIGGERED_PAPER,
        "P-003": OrderState.SUSPENDED, "P-004": OrderState.TRIGGERED_PAPER,
        "P-005": OrderState.SUSPENDED, "P-006": OrderState.TRIGGERED_PAPER,
        "P-007": OrderState.SUSPENDED, "P-008": OrderState.TRIGGERED_PAPER,
        "P-009": OrderState.TRIGGERED_PAPER, "P-010": OrderState.SUSPENDED,
        "P-011": OrderState.TRIGGERED_PAPER, "P-012": OrderState.SUSPENDED,
        "P-013": OrderState.PARTIALLY_REVOKED,  # build_ledger_v1_1 已按裁定⑤部分撤销
    }
    for serial, state in expect.items():
        assert ledger.get(serial).state is state, serial


def test_p013_partially_revoked_wuxi5(ledger: PaperLedger):
    o = ledger.get("P-013")
    assert o.state is OrderState.PARTIALLY_REVOKED
    assert "2359 撤销" in o.memo
    assert "02269" in o.trigger  # 原触发条件保留（终身唯一、作废不删）


def test_p003_voided_not_deleted(ledger: PaperLedger):
    o = ledger.get("P-003")
    o.state = OrderState.VOIDED
    assert ledger.get("P-003") is o


def test_p011_lifeline_triggered_close_all(ledger: PaperLedger):
    """红 C 1/3：SNDK 收 1609.46 < 闸线 1659 → 清仓令已触发（纸面）。"""
    o = ledger.get("P-011")
    assert o.kind is OrderKind.CLOSE_ALL
    assert o.state is OrderState.TRIGGERED_PAPER
    assert "1609.46" in o.trigger and "1659" in o.trigger


def test_p005_gldm_threshold_8529(ledger: PaperLedger):
    o = ledger.get("P-005")
    assert o.kind is OrderKind.BAN_BUY and "85.29" in o.trigger


def test_weekly_review_signature(ledger: PaperLedger):
    line1 = ledger.weekly_review("2026-10-10")
    line2 = ledger.weekly_review("2026-10-16", reviewer="首席投资策略师")
    assert "2026-10-10" in line1 and "v1.1" in line1
    assert len(ledger.signatures) == 2


def test_audit_counts_all_states(ledger: PaperLedger):
    audit = ledger.audit()
    assert set(audit.keys()) == {s.value for s in OrderState}


def test_duplicate_serial_rejected(ledger: PaperLedger):
    with pytest.raises(ValueError):
        ledger.register(PaperOrder("P-003", "2026-10-11", OrderKind.OPEN, "重复编号", "无"))


def test_trigger_requires_valid_state():
    o = PaperOrder("P-999", "2026-10-11", OrderKind.OPEN, "测试", "收盘确认")
    o.mark_filled("纸面成交")
    assert o.state is OrderState.TRIGGERED_PAPER
    with pytest.raises(AssertionError):
        o.mark_filled("重复触发应被拒")
