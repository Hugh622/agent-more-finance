"""四闸系统对账测试：代码模型 ↔ 台账 v1.1 真实快照。"""
import pytest

from tri_market.framework.gates import (
    GateName,
    GATES_SNAPSHOT_20261010,
    POSITION_CAPS,
    can_open_new_position,
)


def test_four_gates_snapshot_matches_ledger_v11():
    used = {g.name: g.used for g in GATES_SNAPSHOT_20261010}
    assert used == {
        GateName.SINGLE_STOCK: 25,
        GateName.THEMATIC: 11,
        GateName.CRYPTO: 4,
        GateName.TOTAL: 33,
    }
    caps = {g.name: g.capacity for g in GATES_SNAPSHOT_20261010}
    assert caps == {
        GateName.SINGLE_STOCK: 28,
        GateName.THEMATIC: 12,
        GateName.CRYPTO: 4,
        GateName.TOTAL: 36,
    }


def test_crypto_gate_full_zero_free_slots():
    crypto = next(g for g in GATES_SNAPSHOT_20261010 if g.name is GateName.CRYPTO)
    assert crypto.free == 0 and crypto.is_full


def test_new_position_blocked_with_reduction_first_rule():
    verdict = can_open_new_position(GATES_SNAPSHOT_20261010)
    assert verdict.allowed_without_reduction is False
    assert "先减后加" in verdict.reason
    # 加密 4/4 满闸；主题 11/12 仅余 1 格同判（free≤1 与 full 同判）
    assert GateName.CRYPTO in verdict.blocked_by
    assert GateName.THEMATIC in verdict.blocked_by


def test_spacious_gates_allow():
    from tri_market.framework.gates import Gate
    spacious = (Gate(GateName.SINGLE_STOCK, 10, 28), Gate(GateName.TOTAL, 15, 36))
    verdict = can_open_new_position(spacious)
    assert verdict.allowed_without_reduction is True


def test_position_caps_documented():
    assert "港股单标的" in POSITION_CAPS and "≤7%" in POSITION_CAPS["港股单标的"]
    assert POSITION_CAPS["试仓"] == "≤2%"
