"""执行线类型状态机测试：七类触发语义（台账 v1.1 口径）。"""
import pytest

from tri_market.execution.lines import LINES_20261010, LineKind, ExecutionLine
from tri_market.quant_leg.indicators import (
    breakout_two_of_three,
    friday_sliding_review,
    pullback_zone_check,
)


def test_lines_snapshot_registered():
    codes = [l.code for l in LINES_20261010]
    assert len(codes) >= 10
    assert len(codes) == len(set(codes))  # 编码唯一
    kinds = {l.kind for l in LINES_20261010}
    assert kinds == set(LineKind)  # 七类语义在 10/10 快照中全部在册


def test_msft_pullback_forbid_chase():
    """MSFT 回踩触发制：10/9 收 535.07 距区顶 517.5 +3.4% → 禁追等回踩（裁定⑥）。"""
    line = next(l for l in LINES_20261010 if l.code == "MSFT.OQ")
    assert line.kind is LineKind.PULLBACK_ZONE and line.values == (513.7, 517.5)
    r = pullback_zone_check(535.07, 513.7, 517.5)
    assert r["in_zone"] is False
    assert r["above_top_pct"] == pytest.approx(3.4, abs=0.05)
    assert "禁追" in r["verdict"]
    assert pullback_zone_check(516.0, 513.7, 517.5)["in_zone"] is True


def test_spcx_ladder_semantics():
    line = next(l for l in LINES_20261010 if l.code == "SPCX.OQ")
    assert line.kind is LineKind.LADDER
    assert line.values == (153.0, 149.9, 145.4)
    assert line.metadata["cap_november"].endswith("≤4%")


def test_snow_two_of_three_breakout():
    line = next(l for l in LINES_20261010 if l.code == "SNOW.N")
    assert line.kind is LineKind.BREAKOUT_CONFIRM
    assert breakout_two_of_three([369.2, 371.0, 369.8], 369.0, 370.0)["confirmed"] is True
    assert breakout_two_of_three([360.0, 371.0, 375.0], 369.0, 370.0)["confirmed"] is False


def test_disarmed_line_02269():
    line = next(l for l in LINES_20261010 if l.code == "02359.HK")
    assert line.armed is False and line.kind is LineKind.PULLBACK_ZONE


def test_dual_confirm_lines_present():
    gldm = next(l for l in LINES_20261010 if l.code == "GLDM.AM")
    assert LineKind.DUAL_CONFIRM in (gldm.kind,) or gldm.metadata["second_confirm"] == "50MA 走平/回升同日成立"
    assert gldm.values[0] == 85.29


def test_friday_sliding_review_semantics():
    """判例①：MA 类线周五统一滑动刷新，固定值仅作快照存档。"""
    closes = [100.0 + i for i in range(250)]
    res = friday_sliding_review(closes, (50, 200))
    assert res[50] == pytest.approx(sum(closes[-50:]) / 50)
    assert res[200] == pytest.approx(sum(closes[-200:]) / 200)
