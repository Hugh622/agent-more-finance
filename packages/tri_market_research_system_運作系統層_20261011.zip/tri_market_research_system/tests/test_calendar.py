"""节点日历引擎测试：裁决点 + 预写动作 + 23×5 制度切换链。"""
from tri_market.calendar.events import EVENTS, EventKind, on, upcoming


def test_october14_cpi_dual_condition():
    evs = on("2026-10-14")
    assert evs and evs[0].kind is EventKind.MACRO_DATA
    joined = "\n".join(evs[0].actions)
    assert "85.29" in joined and "<60%" in joined  # GLDM 双确认＋12月加息<60%
    assert "5.30" in joined  # 10Y 三闸


def test_october16_first_friday_review_and_ledger_v2():
    evs = on("2026-10-16")
    names = " ".join(e.name for e in evs)
    actions = " ".join(a for e in evs for a in e.actions)
    assert "滑动复核" in names and "周检" in names
    assert "台账" in actions and "v2" in actions and "量化腿统一刷新" in actions


def test_us24h_regime_chain():
    """23×5 制度切换链：12/6 T-0 滑动锚 → 12/7 首夜 → 12/8-9 高压校准 → 2027-03-14 满血。"""
    d6 = on("2026-12-06")[0]
    assert d6.kind is EventKind.REGIME_CHANGE
    assert any("不早于" in a for a in d6.actions)  # 滑动锚解包在预写动作里
    assert any("NYSE" in a for a in d6.actions)    # 协议第 0 条：前一周官方终核
    d7 = on("2026-12-07")[0]
    # 首夜三改：首日回填 / 量能基线 20 日重算 / 缺口定义重写（真跳空=越隔夜段高低）
    assert any("首日数据回填" in a for a in d7.actions)
    assert any("量能基线" in a and "20 日重算" in a for a in d7.actions)
    assert any("真跳空" in a for a in d7.actions)
    d89 = on("2026-12-08") + on("2026-12-09")
    assert any("23×5" in e.name or "FOMC" in e.name for e in d89)
    mar = on("2027-03-14")[0]
    assert "满血" in mar.name and any("09:00" in a for a in mar.actions)


def test_g2_acceptance_gate():
    g2 = on("2026-12-18")[0]
    assert g2.kind is EventKind.ACCEPTANCE
    assert any("通过才谈正式执行" in a for a in g2.actions)  # 验收不通过=继续纸面


def test_upcoming_ordering():
    nxt = upcoming("2026-10-11")
    assert nxt[0].date == "2026-10-12"          # W0 起跑
    assert [e.date for e in nxt] == sorted(e.date for e in nxt)


def test_calendar_coverage():
    assert len(EVENTS) >= 24
    kinds = {e.kind for e in EVENTS}
    assert {EventKind.WEEKLY_CHECK, EventKind.SLIDING_REVIEW, EventKind.ACCEPTANCE} <= kinds
