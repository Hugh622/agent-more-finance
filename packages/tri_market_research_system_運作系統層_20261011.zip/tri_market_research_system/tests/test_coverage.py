"""覆盖矩阵校验器测试：对账真实 CSV（212 只，10/9 收盘锚）。

数据引用纪律（判例④）：全体系引用一律以覆盖矩阵 CSV 为准。
"""
from pathlib import Path

import pytest

from tri_market.data_leg.coverage import CoverageMatrix, iter_codes

DATA_DIR = Path(__file__).resolve().parents[1] / "data"
CSV = DATA_DIR / "coverage" / "池子全清单_数据覆盖矩阵_20261010.csv"


@pytest.fixture(scope="module")
def matrix() -> CoverageMatrix:
    return CoverageMatrix.load(CSV)


def test_212_symbols_loaded(matrix: CoverageMatrix):
    assert matrix.source_path is not None
    assert matrix.stats()["total"] == 212


def test_anchor_close_matches_chief_verdict(matrix: CoverageMatrix):
    """对账首席 10/10 终审口径：MSFT 535.07 / XOM 168.94 / CVX 211.98（判例③）。"""
    msft = matrix.find("usMSFT.OQ")
    assert msft and msft.last_close == 535.07 and msft.last_date == "2026-10-09"
    xom = matrix.find("usXOM.N")
    assert xom and xom.last_close == 168.94
    cvx = matrix.find("usCVX.N")
    assert cvx and cvx.last_close == 211.98


def test_cybersec_rotation_rows(matrix: CoverageMatrix):
    """网安 A 股轮换三备选（裁定⑦）：688023/300454/002439。"""
    for code in ("sh688023", "sz300454", "sz002439"):
        row = matrix.find(code)
        assert row is not None, code
        assert "网安" in row.annual_review_tier


def test_us_suffix_rules_held(matrix: CoverageMatrix):
    """集成约定②：美股后缀严格区分交易所（.OQ/.N/.AM）。"""
    assert matrix.suffix_violations() == []


def test_thin_history_flags_known_gap(matrix: CoverageMatrix):
    thin = {r.code: r.rows for r in matrix.thin_history()}
    assert thin.get("usIGV.OQ") == 1  # 已知缺口：IGV 周一 06:30 自愈
    # 除已知缺口 IGV 外，全矩阵 K 线行数 ≥250（251 亦允许，如 WMT/QS）
    others = {k: v for k, v in thin.items() if k != "usIGV.OQ"}
    assert all(v >= 250 for v in others.values()), others


def test_annual_check_report_smoke(matrix: CoverageMatrix):
    report = matrix.annual_check_report()
    assert "212" in report and "年检就绪率" in report


def test_iter_codes_by_review_tier(matrix: CoverageMatrix):
    infra = iter_codes(matrix, ["指数/总闸"])
    assert "sh000001" in infra and "hkHSI" in infra and "usINX" in infra
    assert "sh000300" not in infra  # 沪深300 归属「基础设施池」
