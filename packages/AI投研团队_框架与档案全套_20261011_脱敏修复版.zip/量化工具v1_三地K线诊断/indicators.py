# -*- coding: utf-8 -*-
"""
技术指标计算库（纯pandas实现，无talib依赖）
============================================
指标: MA / EMA / MACD(12,26,9) / BOLL(20,2) / RSI14(Wilder) / 量价关系
所有函数直接在DataFrame上追加列。
"""
import numpy as np
import pandas as pd


def ema(s: pd.Series, n: int) -> pd.Series:
    return s.ewm(span=n, adjust=False).mean()


def add_ma(df: pd.DataFrame, periods=(5, 10, 20, 60)):
    for n in periods:
        df[f"ma{n}"] = df["close"].rolling(n).mean()
    return df


def add_macd(df: pd.DataFrame, fast=12, slow=26, sig=9):
    dif = ema(df["close"], fast) - ema(df["close"], slow)
    dea = ema(dif, sig)
    df["dif"], df["dea"], df["macd"] = dif, dea, 2 * (dif - dea)
    return df


def add_boll(df: pd.DataFrame, n=20, k=2):
    mid = df["close"].rolling(n).mean()
    std = df["close"].rolling(n).std(ddof=0)
    df["boll_mid"] = mid
    df["boll_up"] = mid + k * std
    df["boll_low"] = mid - k * std
    df["boll_bw"] = (df["boll_up"] - df["boll_low"]) / mid  # 带宽
    df["boll_pb"] = (df["close"] - df["boll_low"]) / (df["boll_up"] - df["boll_low"])  # %B
    return df


def add_rsi(df: pd.DataFrame, n=14):
    """Wilder平滑RSI，与主流行情软件口径一致。"""
    delta = df["close"].diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    ag = gain.ewm(alpha=1 / n, adjust=False).mean()
    al = loss.ewm(alpha=1 / n, adjust=False).mean()
    rs = ag / al.replace(0, np.nan)
    df["rsi"] = (100 - 100 / (1 + rs)).fillna(50.0)
    return df


def add_volume(df: pd.DataFrame):
    """量能结构: 5日均量/20日均量比、单日量变、单日涨跌。"""
    df["vr_5_20"] = df["volume"].rolling(5).mean() / df["volume"].rolling(20).mean()
    df["v_chg"] = df["volume"] / df["volume"].shift(1) - 1
    df["p_chg"] = df["close"] / df["close"].shift(1) - 1
    return df


def prepare(df: pd.DataFrame) -> pd.DataFrame:
    """一键计算全部指标。"""
    df = df.copy()
    add_ma(df)
    add_macd(df)
    add_boll(df)
    add_rsi(df)
    add_volume(df)
    return df
