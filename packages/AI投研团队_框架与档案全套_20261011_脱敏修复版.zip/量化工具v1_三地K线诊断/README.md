# 量化工具 v1 — 三地统一K线 + 批量技术诊断

2026-09-12 上线（资深量化技术专家），供全栈开发直接集成进统一数据管道。

## 模块清单
| 文件 | 职责 |
|---|---|
| tencent_kline.py | 三地统一K线抓取（A股/港股/美股同一入口，标准化DataFrame输出）|
| indicators.py | 指标库：MA5/10/20/60、MACD(12,26,9)、BOLL(20,2)、RSI14(Wilder)、量比，纯pandas无talib依赖 |
| diagnosis.py | 单标的诊断逻辑 + Markdown报告渲染（趋势/偏向评分/支撑压力/风险信号）|
| watchlist.py | 三地标的池 + 美股后缀规则 + AH对占位（下一步AH溢价模块用）|
| run_batch.py | 批量入口：`python3 run_batch.py --count 250` |

## 关键调用约定（给全栈开发）
1. **美股代码后缀规则（已实测全通）**：NASDAQ→`usXXX.OQ`，NYSE→`usXXX.N`。
   接口param必须为 `"{code},day,,,{count},qfq"`（count在第4段，日期留空）。昨日实测未通应为param拼法问题。
2. **无效/退市标的**：接口返回 `v_pv_none_match`，`fetch_kline` 返回 `None`，调用方需容错记录，勿中断批次。
3. **标准化输出列**：`date, open, close, high, low, volume`（时间正序）；A股volume=手，港美股=股，跨市场比较一律用比率。
4. **频率**：日K每日收盘后跑一次（A/H当日16:30后，美股北京时间清晨）即可；分钟级(5/15/60)为v2增强项。
5. **示例输出**：`示例输出/klines/*.csv` 即目标标准化格式样例，`示例输出/summary.csv` 为诊断摘要，可直接进看板。

## 待办（v2）
- AH溢价联动跟踪（AH_PAIRS已占位）｜分钟级美股盘中数据｜轻量回测框架｜美股核心池扩充至30只并交全栈建代码映射表
