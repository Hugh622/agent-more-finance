# -*- coding: utf-8 -*-
"""
三地统一K线获取模块（腾讯财经API）
==================================
代码规则（三地统一入口，调用方无需感知市场差异）:
  A股:  sh600519 / sz000858 / sz300750   （sh=沪, sz=深）
  港股: hk00700                          （5位数字）
  美股: usAAPL.OQ (NASDAQ) / usBABA.N (NYSE) / usBRK.A.N (NYSE-A类)
        —— 后缀规则: NASDAQ=.OQ, NYSE=.N; 2026-09-12 实测全通
退市/无效标的: 接口返回 v_pv_none_match, 本模块返回 None 并可回调记录。

数据列（统一标准化输出，时间正序）:
  date(datetime) open close high low volume  —— volume为原始计量单位
  （A股=手, 港美股=股），跨市场比较请一律用比率勿用绝对值。
"""
import time
import requests
import pandas as pd

KLINE_URL = "https://web.ifzq.gtimg.cn/appstock/app/fqkline/get"
HEADERS = {"User-Agent": "Mozilla/5.0", "Referer": "https://gu.qq.com/"}
COLS = ["date", "open", "close", "high", "low", "volume"]


def fetch_kline(code: str, freq: str = "day", count: int = 250,
                adjust: str = "qfq", retries: int = 3) -> "pd.DataFrame | None":
    """拉取单只标的K线, 返回标准化DataFrame; 无效/退市代码返回 None。

    freq: day / week / month
    adjust: qfq前复权(默认) / 空串不复权 —— 港美股该参数被接口忽略, 自动降级为原始day
    """
    param = f"{code},{freq},,,{count},{adjust}"
    for i in range(retries):
        try:
            r = requests.get(KLINE_URL, params={"param": param},
                             headers=HEADERS, timeout=15)
            data = r.json().get("data", {})
            if code not in data:
                return None  # v_pv_none_match 等无效情形
            node = data[code]
            # A股前复权键=qfqday; 港/美股及不复权=day; 周线=qfqweek/week
            key = None
            for k in (f"{adjust}{freq}", freq, f"{freq}{adjust}"):
                if k in node and node[k]:
                    key = k
                    break
            if not key:
                return None
            rows = node[key]
            df = pd.DataFrame([x[:6] for x in rows], columns=COLS)
            df["date"] = pd.to_datetime(df["date"])
            for c in COLS[1:]:
                df[c] = pd.to_numeric(df[c], errors="coerce")
            return df.dropna().sort_values("date").reset_index(drop=True)
        except Exception:
            time.sleep(1 + i)
    return None


def fetch_batch(codes: list, freq: str = "day", count: int = 250,
                sleep: float = 0.35) -> dict:
    """批量拉取, 返回 {code: DataFrame}，失败的自动跳过。"""
    out = {}
    for c in codes:
        df = fetch_kline(c, freq=freq, count=count)
        if df is not None and len(df) >= 30:
            out[c] = df
        time.sleep(sleep)
    return out


if __name__ == "__main__":
    for c in ["sh600519", "hk00700", "usAAPL.OQ"]:
        df = fetch_kline(c, count=5)
        print(c, "->", "OK" if df is not None else "FAIL", 
              df["date"].iloc[-1].date() if df is not None else "")
