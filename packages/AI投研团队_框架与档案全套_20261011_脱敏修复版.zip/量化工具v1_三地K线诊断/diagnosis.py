# -*- coding: utf-8 -*-
"""
单标的技术面诊断 + 批量诊断 + Markdown报告生成
================================================
输出要求（验收标准）:
  1) 明确趋势周期判断（多头/空头/震荡 + 均线排列）
  2) 具体关键点位: 支撑1/支撑2、压力1/压力2
  3) 明确偏向性结论: 看涨 / 看跌 / 中性（附评分）
  4) 量价关系与风险信号（超买超卖、背离、布林开口）
点位规则（客观可复现）:
  压力1 = 近20日最高价    压力2 = 近60日最高价
  支撑1 = 近10日最低价    支撑2 = 近30日最低价
  动态参考: MA20 / BOLL中轨
"""
import numpy as np
import pandas as pd

MARKET_NAME = {"A": "A股", "HK": "港股", "US": "美股"}


def _cross_recent(df: pd.DataFrame, col="macd", lookback=3):
    """近lookback日内DIF/DEA金叉或死叉。"""
    s = np.sign(df[col])
    for i in range(max(1, len(df) - lookback), len(df)):
        a, b = s.iloc[i - 1], s.iloc[i]
        if a != 0 and b != 0 and a != b:
            return "金叉" if b > 0 else "死叉"
    return None


def diagnose(code: str, name: str, market: str, df: pd.DataFrame) -> dict:
    d = df.copy()
    c = d["close"].iloc[-1]
    ma5, ma10, ma20, ma60 = [d[f"ma{n}"].iloc[-1] for n in (5, 10, 20, 60)]
    ma20_slope = (d["ma20"].iloc[-1] / d["ma20"].iloc[-6] - 1) * 100

    # ---- 趋势 ----
    if ma5 > ma10 > ma20 > ma60:
        trend = "多头排列"
    elif ma5 < ma10 < ma20 < ma60:
        trend = "空头排列"
    else:
        trend = "均线纠缠(震荡)"
    above = int(sum(c > m for m in (ma5, ma10, ma20, ma60)))

    # ---- MACD ----
    dif, dea, hist = d["dif"].iloc[-1], d["dea"].iloc[-1], d["macd"].iloc[-1]
    cross = _cross_recent(d)
    macd_pos = "0轴上方" if dif > 0 else "0轴下方"
    hist_dir = "柱体放大" if abs(hist) > abs(d["macd"].iloc[-2]) else "柱体收敛"
    macd_desc = f"DIF {dif:.2f}/DEA {dea:.2f}，{macd_pos}" + \
                (f"{'金叉' if dif > dea else '死叉'}状态" if dif != dea else "") + \
                (f"，近3日{cross}，{hist_dir}" if cross else f"，{hist_dir}")

    # ---- BOLL ----
    pb, bw = d["boll_pb"].iloc[-1], d["boll_bw"].iloc[-1]
    bw_chg = bw - d["boll_bw"].iloc[-6]
    boll_state = "开口扩张" if bw_chg > 0.002 else ("收口" if bw_chg < -0.002 else "走平")
    boll_pos = ("上轨外(极强/超买)" if pb > 1 else "上半区" if pb > 0.5
                else "下半区" if pb > 0 else "下轨外(极弱/超卖)")

    # ---- RSI ----
    rsi = d["rsi"].iloc[-1]
    rsi_zone = ("超买(>70)" if rsi > 70 else "偏强(50-70)" if rsi >= 50
                else "偏弱(30-50)" if rsi >= 30 else "超卖(<30)")

    # ---- 量价 ----
    vr = d["vr_5_20"].iloc[-1]
    p_chg = d["p_chg"].iloc[-1] * 100
    v_chg = d["v_chg"].iloc[-1] * 100
    if vr >= 1.2 and p_chg > 0.5:
        vp = "放量上涨，量价配合"
    elif vr >= 1.2 and p_chg < -0.5:
        vp = "放量下跌，抛压沉重"
    elif vr < 0.8 and p_chg > 0.5:
        vp = "缩量上涨，追涨动能存疑"
    elif vr < 0.8 and p_chg < -0.5:
        vp = "缩量回调，抛压趋缓"
    else:
        vp = "量能中性"
    near_high = c >= d["high"].iloc[-20:].max() * 0.995
    near_low = c <= d["low"].iloc[-20:].min() * 1.005
    warnings = []
    if near_high and vr < 0.8:
        warnings.append("价临20日新高但量能萎缩，警惕顶背离")
    if near_low and vr > 1.5:
        warnings.append("低位天量，关注资金承接与止跌信号")

    # ---- 点位 ----
    res1 = d["high"].iloc[-20:].max()
    res2 = d["high"].iloc[-60:].max()
    sup1 = d["low"].iloc[-10:].min()
    sup2 = d["low"].iloc[-30:].min()
    chg5 = (c / d["close"].iloc[-6] - 1) * 100

    # ---- 评分与偏向 ----
    score = 0
    score += 2 if trend == "多头排列" else (-2 if trend == "空头排列" else 0)
    score += 1 if c > ma20 else -1
    score += 1 if dif > dea else -1
    score += 1 if dif > 0 else -1
    score += 1 if rsi >= 50 else -1
    if rsi > 75:
        score -= 1
        warnings.append("RSI严重超买，短线回撤风险高")
    elif rsi < 25:
        score += 1
        warnings.append("RSI深度超卖，存在技术性反弹动能")
    if vr >= 1.2 and p_chg > 0.5:
        score += 1
    elif vr >= 1.2 and p_chg < -0.5:
        score -= 1
    bias = "看涨" if score >= 2 else ("看跌" if score <= -2 else "中性震荡")

    return {
        "code": code, "name": name, "market": market,
        "last_date": str(d["date"].iloc[-1].date()), "close": c,
        "chg5": chg5, "trend": trend, "above": above, "ma20_slope": ma20_slope,
        "macd": macd_desc, "boll": f"%B {pb:.2f}（{boll_pos}），带宽{boll_state}",
        "rsi": rsi, "rsi_zone": rsi_zone, "vp": vp, "vr": vr,
        "warnings": warnings, "score": score, "bias": bias,
        "sup1": sup1, "sup2": sup2, "res1": res1, "res2": res2,
        "ma20": ma20, "boll_mid": d["boll_mid"].iloc[-1],
    }


def render_report(results: list) -> str:
    """批量诊断 → Markdown报告。"""
    lines = []
    last_dates = sorted({r["last_date"] for r in results})
    lines.append("# 三地市场技术面批量诊断报告\n")
    lines.append(f"> 数据截至: {last_dates[-1]}（各市场最近交易日收盘）｜"
                 f"指标: MA5/10/20/60, MACD(12,26,9), BOLL(20,2), RSI14(Wilder), 量比=5日均量/20日均量\n")

    # 摘要表
    lines.append("## 一、诊断总览\n")
    lines.append("| 市场 | 代码 | 名称 | 现价 | 5日涨跌 | 趋势 | MACD状态 | RSI14 | 量比 | 偏向(评分) |")
    lines.append("|---|---|---|---|---|---|---|---|---|---|")
    for r in results:
        macd_short = "多头" if "金叉状态" in r["macd"] or ("0轴上方" in r["macd"] and "死叉" not in r["macd"]) else "空头"
        lines.append(
            f"| {MARKET_NAME[r['market']]} | {r['code']} | {r['name']} | {r['close']:.2f} "
            f"| {r['chg5']:+.1f}% | {r['trend']} | {macd_short} | {r['rsi']:.0f} "
            f"| {r['vr']:.2f} | **{r['bias']}**({r['score']:+d}) |")

    # 分市场明细
    lines.append("\n## 二、分标的明细\n")
    for mk in ("A", "HK", "US"):
        sub = [r for r in results if r["market"] == mk]
        if not sub:
            continue
        lines.append(f"### {MARKET_NAME[mk]}\n")
        for r in sub:
            warn = ("⚠️ " + "；".join(r["warnings"])) if r["warnings"] else "无明显风险信号"
            lines.append(f"#### {r['code']} {r['name']}")
            lines.append(f"- 现价 **{r['close']:.2f}**（近5日 {r['chg5']:+.1f}%）｜"
                         f"趋势: {r['trend']}，MA20斜率 {r['ma20_slope']:+.2f}%/周")
            lines.append(f"- MACD: {r['macd']}")
            lines.append(f"- BOLL: {r['boll']}")
            lines.append(f"- RSI14: {r['rsi']:.1f}（{r['rsi_zone']}）")
            lines.append(f"- 量价: 量比 {r['vr']:.2f}，{r['vp']}")
            lines.append(f"- **结论: {r['bias']}（评分{r['score']:+d}）** ｜ "
                         f"支撑1 {r['sup1']:.2f}（10日低）｜支撑2 {r['sup2']:.2f}（30日低）｜ "
                         f"压力1 {r['res1']:.2f}（20日高）｜压力2 {r['res2']:.2f}（60日高）")
            lines.append(f"- 风控提示: {warn}\n")

    lines.append("## 三、方法论说明\n")
    lines.append("- 趋势判定以均线排列+收盘价相对MA20位置为主，MACD 0轴与金叉死叉确认动能方向；")
    lines.append("- 点位均为客观计算值（N日高低点），未叠加主观整数关口；")
    lines.append("- 偏向评分区间[-7,+7]：≥+2看涨、≤-2看跌、其间为中性震荡；评分仅供排序参考，"
                 "超买/背离等风险信号以明细为准。")
    return "\n".join(lines)
