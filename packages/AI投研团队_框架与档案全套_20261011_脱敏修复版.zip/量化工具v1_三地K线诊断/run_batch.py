# -*- coding: utf-8 -*-
"""
批量诊断入口
============
用法:
  python3 run_batch.py                # 默认标的池, 日K 250根
  python3 run_batch.py --count 120    # 拉取K线根数
输出:
  out/report_YYYYMMDD.md              # Markdown诊断报告
  out/klines/{code}.csv               # 标准化K线(含指标), 供数据管道/看板直接复用
  out/summary.csv                     # 诊断摘要表
"""
import argparse
import os
import sys

import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from tencent_kline import fetch_batch          # noqa: E402
from indicators import prepare                  # noqa: E402
from diagnosis import diagnose, render_report   # noqa: E402
from watchlist import WATCHLIST                 # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--count", type=int, default=250)
    ap.add_argument("--outdir", default="out")
    args = ap.parse_args()

    codes, meta = [], {}
    for mk, items in WATCHLIST.items():
        for code, name in items:
            codes.append(code)
            meta[code] = (name, mk)

    print(f"[1/3] 拉取 {len(codes)} 只三地标的日K({args.count}根)...")
    raw = fetch_batch(codes, count=args.count)

    print(f"[2/3] 计算指标并诊断（成功 {len(raw)}/{len(codes)} 只）...")
    results, kline_frames = [], {}
    for code, df in raw.items():
        name, mk = meta[code]
        d = prepare(df)
        results.append(diagnose(code, name, mk, d))
        kline_frames[code] = d

    results.sort(key=lambda r: ({"A": 0, "HK": 1, "US": 2}[r["market"]], -r["score"]))

    print("[3/3] 生成报告与标准化数据文件...")
    os.makedirs(args.outdir, exist_ok=True)
    kdir = os.path.join(args.outdir, "klines")
    os.makedirs(kdir, exist_ok=True)
    for code, d in kline_frames.items():
        num = d.select_dtypes("number").round(4)
        num.insert(0, "date", d["date"].dt.date)
        num.to_csv(os.path.join(kdir, f"{code}.csv"), index=False)

    report = render_report(results)
    report_path = os.path.join(args.outdir, "report_batch.md")
    with open(report_path, "w", encoding="utf-8") as f:
        f.write(report)

    pd.DataFrame([{k: r[k] for k in ("market", "code", "name", "close", "chg5", "trend",
                                     "rsi", "vr", "score", "bias", "sup1", "sup2",
                                     "res1", "res2")} for r in results]).round(2) \
        .to_csv(os.path.join(args.outdir, "summary.csv"), index=False)

    print(f"完成: {report_path} | {args.outdir}/summary.csv | {args.outdir}/klines/*.csv")
    for r in results:
        print(f"  {r['code']:<12} {r['name']:<6} {r['bias']}({r['score']:+d}) "
              f"现价{r['close']:.2f} 支撑{r['sup1']:.2f}/{r['sup2']:.2f} "
              f"压力{r['res1']:.2f}/{r['res2']:.2f}")


if __name__ == "__main__":
    main()
