# Ahju 學習原則清單（一頁版）
**來源：** ①量化技術專家《Ahju Q&A 交易／技術面觀點評析》②首席投資策略師《Ahju Q&A 資產配置觀點評析》（均為 2026-09-27）｜**整理：** 通用助手 ｜ 2026-09-27
**用法：** 每次做配置／開倉決策前，對照打勾。☐ 未做 → 唔好落場。｜ Checklist — tick before every allocation or entry decision.

---

## A. 配置層（來源：首席策略師評析）
- [ ] **由目標倒推配置**：先鎖定年齡／資產／最大可忍受回撤，再倒推長線回報與短炒貢獻；順序不可倒轉。｜ Work backwards from goals (age, wealth, max drawdown) — never reverse the order.
- [ ] **拒絕假精確**：唔知前提嘅「60/30/10」係噪音；可以抄「骨」，唔可以抄「數」。｜ Refuse pseudo-precise numbers without context.
- [ ] **倒推要雙向收斂**：倒推出「需要年化15%」而市場只畀6–8% → 修改目標，唔係加倉就個數。｜ If goal > market reality, revise the goal, not leverage up.
- [ ] **資金池行為隔離（兩本帳）**：trading池靠眼光＋止損紀律；長線池刻意拒絕眼光。｜ Two-book firewall: judgement lives only in the risk-managed trading book.
- [ ] **利潤沉澱單向閘**：trading利潤強制轉入長線池（alpha沉澱做beta），切斷「贏咗加賭注」賭徒螺旋。｜ Forced profit recycling: alpha → beta, one way only.
- [ ] **短炒倉位上限＝已驗證edge嘅函數**；冇edge就係零（佢冇講、必須補嘅硬約束）。｜ Trading sleeve = f(proven edge); zero if none.
- [ ] **「大跌加碼」設年度預算閘**：超賣可以連續超賣幾年（2008／日經1990s），冇預算上限會喺尾部事件超買。｜ Annual budget cap on dip-adding — oversold can stay oversold for years.
- [ ] **記住 lump sum 事實**：一筆過資金（花紅／賣樓）統計上應即時投入；DCA只係行為面折衷，唔係期望回報更優。｜ Windfalls: lump sum beats DCA ~68% of the time (Vanguard 2012).

## B. 執行層（來源：量化技術專家評析）
- [ ] **用規則代替預測**：接受冇人知幾時見底；「覺得超賣」唔係入場理由，要有量化定義。｜ Rule-based, not forecast-based.
- [ ] **whipsaw市＝主動降頻**：「唔好outsmart個市場」；唔追gap up——「之前冇買到」從來唔係買入理由。｜ In whipsaw regimes, the edge is NOT trading; sunk cost of missing out is never a buy signal.
- [ ] **環境決定策略，唔係反轉**：強市／弱市分開兩本劇本；形態（如HTF）只喺確認升市做。｜ Regime first, pattern second.
- [ ] **盤中買＝用倉位換時間**：只做「試倉」≤1/3，收盤確認（量≥1.5×＋收喺旗頂上）先補足，否則試倉即止損。｜ Intraday entry = probe position only; full size waits for the close to confirm.
- [ ] **突破日量硬門檻**：HTF突破日量≥1.5×20日均量；<1.0×唔係「麻麻哋」，係直接不合格。｜ Breakout volume ≥1.5×20-day average; <1.0× = outright fail.
- [ ] **形態必加相對強度過濾**：RS與板塊同行先完整（SPCX教訓：形態＋量達標、RS差照減倉）。｜ Always add relative-strength filter to chart patterns.
- [ ] **事件日曆＝交易否決權**：IPO解禁（+180/+365日）自動標記；解禁股數/自由流通量>50%高危、>100%禁做多。｜ Lock-up expiry is a dated supply shock — check the event calendar before any long.
- [ ] **解禁唔係「避到永遠」**：解禁前禁做多；解禁後縮量企穩（量比<0.8×連續5日＋收復解禁日收盤價）→重新評級。｜ No longs into the window; reassess after quiet-volume stabilization.
- [ ] **規模意識**：藍籌幾日成交量嘅解禁 vs 巨型解禁係兩回事；先睇股本結構，再睇形態。｜ Size the unlock against free float before reading the chart.

## C. 心法（兩份評析共同結論）
- [ ] **學骨唔學皮**：骨＝資金池隔離、目標倒推、長線池唔擇時、利潤強制沉澱——即刻抄得；皮＝佢嘅短炒手法，建基於佢自己已驗證嘅edge同速度。｜ Learn the skeleton, not the skin: copy the process, not the tactics.
- [ ] **最危險嘅位係「佢冇講嘅前提」**：整套系統預設「已驗證edge＋頂得住兩池心理撕裂」；只學一半＝「冇紀律嘅短炒＋冇耐性嘅長供」最差組合。｜ The danger isn't what he gets wrong — it's the preconditions he leaves unstated.

---
*一句總結：Ahju係「過濾器優先、頻率讓路」嘅裁量派；本群係「確認制優先、規則可證偽」嘅量化派——四項觀點無一項要推翻，融合落點喺「試倉—確認」兩段制同事件日曆否決權。*
