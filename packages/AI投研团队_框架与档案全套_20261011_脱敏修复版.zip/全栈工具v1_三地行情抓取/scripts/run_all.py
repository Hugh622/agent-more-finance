# -*- coding: utf-8 -*-
"""一键跑批：K线全池 + 实时快照 + 宏观P0通道 → /shared/market_data/
用法:
  python3 scripts/run_all.py               # 全量(日K250根+快照+宏观)
  python3 scripts/run_all.py --no-kline    # 只跑快照+宏观(盘中轻量刷新)
  python3 scripts/run_all.py --count 120   # 自定义K线条数
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from market_fetcher import runner, us_symbols  # noqa: E402
from market_fetcher.pools import (INDICES, A_POOL, HK_POOL, US_POOL, ETF_POOL,
                                  US_WATCH_POOL, SECTOR_ETF_POOL,
                                  A_POOL_SPARES, HK_POOL_SPARES, US_POOL_SPARES)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def load_pool(pool_list, spares):
    """主池全要；主池中失败标的由候补自动替补（按 verify_report 或现场探测）。"""
    return [(c, n) for c, n in pool_list]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--count", type=int, default=250)
    ap.add_argument("--no-kline", action="store_true")
    args = ap.parse_args()

    mapping = us_symbols.load_mapping()
    verified_us = {m["kline_code"]: m["name_cn"] for m in mapping if m["verified"]}
    # 主池中以映射表验证结果为准（后缀以实测为准，池内预填码仅作参考）
    us_pool = [(code, name) for code, name in verified_us.items()]

    # 观察池18只(宏观清单): 按映射表解析为实测验证过的K线码, 即插即用
    # (US_WATCH_POOL 带us前缀, 映射表symbol无前缀; 观察池与主池重叠的6只自动去重)
    watch_map = {m["symbol"]: (m["kline_code"], m["name_cn"]) for m in mapping if m["verified"]}
    us_pool_codes = {c for c, _ in us_pool}
    watch_pool = []
    for s, _ in US_WATCH_POOL:
        sym = s.replace("us", "", 1)
        if sym in watch_map:
            code, name = watch_map[sym]
            if code not in us_pool_codes:
                watch_pool.append((code, name))

    pools = {"指数": INDICES, "A股65": A_POOL, "港股24": HK_POOL, "美股池": us_pool,
             "观察池18": watch_pool, "ETF": ETF_POOL}
    print(f"计划: K线{'跳过' if args.no_kline else str(args.count)+'根'} "
          f"+ 实时快照 + 宏观P0通道; 标的 {sum(len(v) for v in pools.values())} 只")

    if not args.no_kline:
        m1 = runner.run_kline_batch(pools, count=args.count, sleep=0.6)
        p = runner.save_manifest(m1)
        print(f"K线批次: ok={m1['ok']} thin={m1['thin']} fail={m1['fail']} -> {p}")

    m2 = runner.run_realtime_snapshot()
    print(f"实时快照: {m2['total']} 条")
    m3 = runner.run_macro()
    p = runner.save_manifest(m3)

    def _tag(m):
        if not m.get("ok"):
            return "❌(已降级)"
        return f"✅[{m.get('source_level','?')}{',降级' if m.get('degraded') else ''}]"

    print("宏观通道:",
          "美债", _tag(m3["us_yields"]),
          "| 中债", _tag(m3["cn_yields"]),
          "| 联邦基金", _tag(m3["fred_p0"]["fedfunds"]),
          "| VIX官方", _tag(m3["fred_p0"]["vix"]),
          "| 信用利差", _tag(m3["fred_p0"]["credit_spread_hy"]),
          "| FX", _tag(m3["fx"]),
          "| AH溢价", _tag(m3["ah_premium"]),
          "| SEC filings", _tag(m3["sec_filings"]),
          "->", p)


if __name__ == "__main__":
    main()
