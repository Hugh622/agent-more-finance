# -*- coding: utf-8 -*-
"""三地行情统一抓取模块 v1 —— 全栈开发 2026-09-12
统一入口示例:
    from market_fetcher import tencent_api, runner, us_symbols
    df = tencent_api.fetch_kline("usNVDA.OQ", count=250)   # 与量化模块同约定
    quotes = tencent_api.fetch_realtime(["sh600519", "usAAPL", "whUSDCNY"])
    manifest = runner.run_kline_batch({"美股": us_pool}, count=250)
"""
from . import tencent_api, pools, us_symbols, macro_feeds, storage, runner  # noqa: F401
