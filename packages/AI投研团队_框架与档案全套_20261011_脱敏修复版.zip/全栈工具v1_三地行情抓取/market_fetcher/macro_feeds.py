# -*- coding: utf-8 -*-
"""
宏观P0数据通道（对接 宏观基本面研究员 清单 + 策略师P0 4/5/6/7项）
================================================================
通道实测结论（2026-09-12）:
  ✅ 美债全期限收益率   —— 美国财政部官网 CSV（无需key）
  ✅ 中国国债收益率曲线 —— CFETS 中国货币网 JSON（无需key）
  ✅ 汇率: USDCNY/USDHKD/HKDCNY —— 腾讯外汇通道 wh 前缀
  ✅ 美元指数           —— 腾讯 whDINIW（注意: quote_ts 可能滞后，落盘带原始时间戳）
  ✅ AH溢价             —— 指数通道无(hkHSAHP❌)，改用18对AH双挂牌股实时价自算
  ✅ VHSI 恒指波幅      —— 腾讯 hkVHSI K线直连
  ⚠️ USDCNH 离岸价     —— 腾讯无通道 → 用 USDCNY 在岸价近似（两岸点差通常极窄）+ 检索兜底
  ⚠️ 人民币中间价      —— 无稳定通道 → 检索兜底（外汇局每日9:15公布，录入模板已备）
  ⚠️ VIX               —— 腾讯无通道 → VXX/VIXY 期货ETF代理（落盘明确标注proxy）
  ⚠️ 南向资金          —— 腾讯/东财均不可达 → 检索兜底录入模板（calendar/southbound_template.json）
  ⚠️ FOMC/CPI/非农日历 —— 静态配置（config/fomc_calendar.json）+ 决议结果人工更新
"""
import csv
import io
import json
import os
from datetime import datetime, timedelta

import pandas as pd
import requests

from . import tencent_api, storage, degrade
from .pools import AH_PAIRS

TREASURY_URL = ("https://home.treasury.gov/resource-center/data-chart-center/"
                "interest-rates/daily-treasury-rates.csv/{year}/all?"
                "type=daily_treasury_yield_curve&field_tdr_date_value={year}&page&_format=csv")
CHINAMONEY_URL = ("https://www.chinamoney.com.cn/ags/ms/cm-u-bk-currency/ClsYldCurvHis"
                  "?lang=CN&reference=1&bondType=CYCC000&pageNum={page}&pageSize={size}"
                  "&startDate={start}&endDate={end}")
HEADERS = {"User-Agent": "Mozilla/5.0"}

CONFIG_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "config")


# ---------------------------------------------------------------- 美债收益率
def fetch_us_yields(year: int = None) -> "pd.DataFrame | None":
    """美国财政部日度收益率曲线（全期限, %）。列名: 1 Mo,2 Mo,3 Mo,4 Mo,6 Mo,1 Yr,2 Yr,...,30 Yr"""
    year = year or datetime.now().year
    try:
        r = requests.get(TREASURY_URL.format(year=year), headers=HEADERS, timeout=20)
        r.raise_for_status()
        df = pd.read_csv(io.StringIO(r.text))
        df["Date"] = pd.to_datetime(df["Date"], format="%m/%d/%Y")
        df = df.sort_values("Date")
        df = df.rename(columns={"Date": "date"})
        return df.reset_index(drop=True)
    except Exception:
        return None


def us_yield_p0_files(curve: "pd.DataFrame", outdir: str, fetched_at: str) -> list:
    """宏观P0-1: 2Y/10Y/30Y 三个P0文件 + 全期限curve附赠。"""
    paths = []
    tenors = {"us02y": "2 Yr", "us10y": "10 Yr", "us30y": "30 Yr"}
    for ticker, col in tenors.items():
        if col not in curve.columns:
            continue
        sub = curve[["date", col]].dropna().rename(columns={col: "value"}).tail(30)
        sub.insert(1, "ticker", ticker)
        p = storage.save_csv(sub, os.path.join(outdir, f"{ticker}.csv"),
                             fetched_at, storage.SOURCE_TREASURY)
        paths.append(p)
    curve_path = os.path.join(outdir, "ust_full_curve.csv")
    storage.save_csv(curve.tail(30), curve_path, fetched_at, storage.SOURCE_TREASURY)
    paths.append(curve_path)
    return paths


# ---------------------------------------------------------------- 中国国债
def fetch_cn_yields(days: int = 10) -> "pd.DataFrame | None":
    """CFETS中国货币网 国债收益率曲线（全期限, %）。返回 date,term(年),value 长表。
    ⚠️ 2026-09-12 实测: ClsYldCurvHis 端点(GET/POST均试)仅返回 dateList 元信息,
    曲线数值 records 键不随包返回(需前端配套二次调用)。中债10Y暂走 L2 检索录入登记簿
    (宏观研究员每日CSV), 本函数保留待逆向 v2。"""
    end = datetime.now()
    start = end - timedelta(days=days)
    rows, page = [], 1
    try:
        while page <= 10:
            r = requests.get(CHINAMONEY_URL.format(
                page=page, size=200, start=start.strftime("%Y-%m-%d"),
                end=end.strftime("%Y-%m-%d")), headers=HEADERS, timeout=15)
            data = r.json().get("data", {})
            records = data.get("records") or []
            rows += records
            total_pages = int(data.get("pageTotal") or 1)
            if page >= total_pages or not records:
                break
            page += 1
        if not rows:
            return None
        df = pd.DataFrame([{
            "date": x["newDateValueCN"], "term": float(x["yearTermStr"]),
            "value": float(x["maturityYieldStr"])} for x in rows])
        return df.dropna().sort_values(["date", "term"]).reset_index(drop=True)
    except Exception:
        return None


def cn_yield_p0_files(long_df: "pd.DataFrame", outdir: str, fetched_at: str) -> list:
    """宏观P1利率锚: 中国10Y国债 + 全期限curve。"""
    paths = []
    if long_df is None or long_df.empty:
        return paths
    sub = long_df[long_df["term"] == 10.0][["date", "value"]].copy()
    sub.insert(1, "ticker", "cn10y")
    p = storage.save_csv(sub, os.path.join(outdir, "cn10y.csv"),
                         fetched_at, storage.SOURCE_CHINAMONEY)
    paths.append(p)
    wide = long_df.pivot_table(index="date", columns="term", values="value")
    wide.columns = [f"t{c}y" for c in wide.columns]
    p = storage.save_csv(wide.reset_index(), os.path.join(outdir, "cny_full_curve.csv"),
                         fetched_at, storage.SOURCE_CHINAMONEY)
    paths.append(p)
    return paths


# ---------------------------------------------------------------- 汇率矩阵
FX_CODES = [("whUSDCNY", "usdcny"), ("whUSDHKD", "usdhkd"),
            ("whHKDCNY", "hkdcny"), ("whDINIW", "dxy")]


def run_fx(outdir: str, fetched_at: str) -> dict:
    """汇率三件套+美元指数快照 → 单文件长表 + 宽表矩阵。
    注意: USDCNH(离岸)无通道，用USDCNY近似，gap在README/market_data README标注。
    """
    quotes = {q["code"]: q for q in tencent_api.fetch_realtime([c for c, _ in FX_CODES])}
    rows = []
    for tcode, ticker in FX_CODES:
        q = quotes.get(tcode.replace("wh", ""))
        if not q or q.get("price") is None:
            continue
        rows.append(dict(
            date=datetime.now().strftime("%Y-%m-%d"), ticker=ticker,
            value=q["price"], prev_close=q.get("prev_close"),
            quote_ts=q.get("quote_ts"),
            note="在岸价;离岸USDCNH通道缺失,用USDCNY近似" if ticker == "usdcny" else
                 ("美元指数(whDINIW),时间戳以quote_ts为准" if ticker == "dxy" else "")))
    result = {"ok": bool(rows), "tickers": [r["ticker"] for r in rows]}
    if not rows:
        return result
    long_df = pd.DataFrame(rows)
    p1 = storage.save_csv(long_df, os.path.join(outdir, "fx_snapshot.csv"),
                          fetched_at, storage.SOURCE_TENCENT_RT.format(ts=fetched_at))
    wide = long_df[["date", "ticker", "value"]].pivot_table(index="date", columns="ticker", values="value")
    wide.columns = [f"{c}" for c in wide.columns]
    p2 = storage.save_csv(wide.reset_index(), os.path.join(outdir, "fx_matrix.csv"),
                          fetched_at, storage.SOURCE_TENCENT_RT.format(ts=fetched_at))
    result.update(paths=[p1, p2])
    return result


# ---------------------------------------------------------------- AH溢价（自算）
def run_ah_premium(outdir: str, fetched_at: str) -> dict:
    """AH溢价自算：18对双挂牌 A价(人民币) / H价(港元×HKDCNY) - 1。
    宏观P0-7 替代方案（HSAHP指数腾讯无通道）；与恒生AH溢价指数口径存在成分差异，README已标注。
    """
    a_codes = [a for a, _, _ in AH_PAIRS]
    h_codes = [h for _, h, _ in AH_PAIRS]
    fx_q = [q for q in tencent_api.fetch_realtime(["whHKDCNY"])]
    hkd_cny = fx_q[0]["price"] if fx_q and fx_q[0].get("price") else None
    if not hkd_cny:
        return {"ok": False, "error": "HKDCNY fx missing"}
    quotes = {q["key"]: q for q in tencent_api.fetch_realtime(a_codes + h_codes)}
    rows = []
    for a_code, h_code, name in AH_PAIRS:
        qa, qh = quotes.get(a_code), quotes.get(h_code)
        if not qa or not qh or qa.get("price") is None or qh.get("price") is None:
            rows.append(dict(date=datetime.now().strftime("%Y-%m-%d"), name=name,
                             a_code=a_code, h_code=h_code, a_price=None, h_price=None,
                             hkd_cny=hkd_cny, premium_pct=None, note="quote missing"))
            continue
        premium = qa["price"] / (qh["price"] * hkd_cny) - 1
        rows.append(dict(date=datetime.now().strftime("%Y-%m-%d"), name=name,
                         a_code=a_code, h_code=h_code,
                         a_price=round(qa["price"], 3), h_price=round(qh["price"], 3),
                         hkd_cny=hkd_cny, premium_pct=round(premium * 100, 2),
                         note=""))
    df = pd.DataFrame(rows)
    p = storage.save_csv(df, os.path.join(outdir, "ah_premium.csv"),
                         fetched_at, storage.SOURCE_TENCENT_RT.format(ts=fetched_at) + " 自算A/H价÷HKDCNY")
    return {"ok": True, "paths": [p], "pairs": len(rows),
            "median_premium": df["premium_pct"].median()}


# ---------------------------------------------------------------- 降级链定义（对接 degrade.run_chain）
# 数据形状适配说明:
#   L1 财政部   → 全期限曲线 DataFrame(列: date,1 Mo,...,30 Yr,%)
#   L1 FRED     → 宽表 DataFrame(date,2Y,10Y,30Y,%)
#   L2 登记簿   → records DataFrame(series∈{us02y,us10y,us30y})
def us_yields_chain() -> list:
    """美债收益率降级链: L1财政部 → L1 FRED(DGS2/10/30) → L2检索录入登记簿。
    白名单/核验规则依据 宏观研究员《清单与核验标准 v1》§2.1/§5-1: A级传媒双源一致。"""
    def _records():
        recs = degrade.load_third_party_records()
        if recs is None or recs.empty:
            return None
        sub = recs[recs["series"].isin(["us02y", "us10y", "us30y"])]
        return sub if len(sub) else None
    return [
        {"name": "美国财政部官网", "level": storage.LEVEL_OFFICIAL, "grade": "S",
         "fetch": lambda: fetch_us_yields(), "source": storage.SOURCE_TREASURY},
        {"name": "圣路易斯联储FRED", "level": storage.LEVEL_OFFICIAL, "grade": "S",
         "fetch": lambda: degrade.fetch_fred_us_yields(), "source": storage.SOURCE_FRED},
        {"name": "第三方检索录入登记簿", "level": storage.LEVEL_THIRD_PARTY, "grade": "A/B(已核验)",
         "fetch": _records, "source": "检索录入登记簿-config/third_party_records.json-{ts}"},
    ]


def publish_us_yields(payload, meta: dict, outdir: str, fetched_at: str) -> list:
    """按命中层数据形状发布 P0 文件(us02y/us10y/us30y + 附赠)。"""
    paths = []
    if payload is None:
        return paths
    if isinstance(payload, pd.DataFrame) and "1 Yr" in payload.columns:      # 财政部全期限
        tenors = {"us02y": "2 Yr", "us10y": "10 Yr", "us30y": "30 Yr"}
        for ticker, col in tenors.items():
            if col not in payload.columns:
                continue
            sub = payload[["date", col]].dropna().rename(columns={col: "value"}).tail(30)
            sub.insert(1, "ticker", ticker)
            paths.append(storage.save_csv(sub, os.path.join(outdir, f"{ticker}.csv"),
                                          fetched_at, meta["source"], meta["level"], meta["grade"]))
        paths.append(storage.save_csv(payload.tail(30), os.path.join(outdir, "ust_full_curve.csv"),
                                      fetched_at, meta["source"], meta["level"], meta["grade"]))
    elif isinstance(payload, pd.DataFrame) and "10Y" in payload.columns:      # FRED宽表
        m = {"2Y": "us02y", "10Y": "us10y", "30Y": "us30y"}
        for col, ticker in m.items():
            if col not in payload.columns:
                continue
            sub = payload[["date", col]].dropna().rename(columns={col: "value"}).tail(30)
            sub.insert(1, "ticker", ticker)
            paths.append(storage.save_csv(sub, os.path.join(outdir, f"{ticker}.csv"),
                                          fetched_at, meta["source"], meta["level"], meta["grade"]))
    elif isinstance(payload, pd.DataFrame) and "series" in payload.columns:   # L2登记簿长表
        sub = payload[["as_of", "series", "value", "source_media", "quote_ts",
                       "cross_check_status"]].copy()
        sub = sub.rename(columns={"as_of": "date"})
        paths.append(storage.save_csv(sub.sort_values(["series", "date"]),
                                      os.path.join(outdir, "us_yields_third_party.csv"),
                                      fetched_at, meta["source"], meta["level"], meta["grade"]))
    return paths


def fred_series_chain(series_id: str, series_name: str) -> list:
    """FRED序列通用降级链: L1 FRED → L2登记簿 → (L3人工检索模板)。"""
    sid_l = series_id.lower()
    def _records():
        recs = degrade.load_third_party_records()
        if recs is None or recs.empty:
            return None
        sub = recs[recs["series"] == sid_l]
        return sub if len(sub) else None
    return [
        {"name": f"FRED:{series_id}", "level": storage.LEVEL_OFFICIAL, "grade": "S",
         "fetch": lambda: degrade.fetch_fred_series(series_id),
         "source": storage.SOURCE_FRED},
        {"name": "第三方检索录入登记簿", "level": storage.LEVEL_THIRD_PARTY, "grade": "A/B(已核验)",
         "fetch": _records, "source": "检索录入登记簿-config/third_party_records.json-{ts}"},
    ]


# 宏观P0新增: 联邦基金利率 / VIX官方收盘 / 信用利差(策略师P1信用周期)
FRED_P0_SERIES = {
    "fedfunds": ("DFF", "联邦基金有效利率(日)"),
    "vix": ("VIXCLS", "VIX收盘(官方CBOE)"),
    "credit_spread_hy": ("BAMLH0A0HYM2", "美国高收益债利差(信用周期)"),
}


# ---------------------------------------------------------------- 静态日历
def publish_calendar(outdir: str, fetched_at: str) -> list:
    """FOMC静态日历 + 南向资金检索兜底录入模板 → calendar/。"""
    paths = []
    src_fomc = os.path.join(CONFIG_DIR, "fomc_calendar.json")
    if os.path.exists(src_fomc):
        with open(src_fomc, encoding="utf-8") as f:
            cal = json.load(f)
        p = storage.save_json(cal, os.path.join(outdir, "fomc_calendar.json"),
                              fetched_at=fetched_at, source="静态配置(维护人:宏观研究员);来源:Fed官方会议日程")
        paths.append(p)
    for tmpl in ("southbound_template.json", "us_release_calendar_template.json"):
        src = os.path.join(CONFIG_DIR, tmpl)
        if os.path.exists(src):
            with open(src, encoding="utf-8") as f:
                data = json.load(f)
            p = storage.save_json(data, os.path.join(outdir, tmpl),
                                  fetched_at=fetched_at,
                                  source="检索兜底录入模板(无稳定行情通道,人工/通用助手检索更新)")
            paths.append(p)
    return paths
