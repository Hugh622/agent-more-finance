# -*- coding: utf-8 -*-
"""
腾讯财经 API 统一封装（K线 / 实时快照 / 外汇）
================================================
集成约定（源自 资深量化技术专家 2026-09-12 实测结论，严格沿用）:
  1. K线 param 必须为 "{code},day,,,{count},qfq"（count 在第4段，日期段留空）。
  2. 美股 K线代码后缀: NASDAQ→usXXX.OQ, NYSE→usXXX.N, ETF(Arca/AMEX)→usXXX.AM
     （实时快照则用无后缀 usXXX）。⚠️ 后缀不可混淆: usBABA.OQ 失败而 usBABA.N 正常。
  3. 无效/退市标的: 接口返回 v_pv_none_match → fetch_kline 返回 None，
     调用方需容错记录，单只失败不得中断批次。
  4. 原始行序 [date, open, close, high, low, volume]（腾讯口径），
     对外落盘 CSV 时重排为标准 OHLC（date,open,high,low,close,volume），见 README。

代码规则:
  A股:  sh600519 / sz300750；指数 sh000300 / sz399006
  港股: hk00700；指数 hkHSI / hkHSTECH / hkVHSI
  美股: usAAPL.OQ(NASDAQ) / usBABA.N(NYSE)；指数 usDJI / usIXIC / usINX / usNDX
  外汇: whUSDCNY / whUSDHKD / whHKDCNY / whDINIW(美元指数)
"""
import time
import requests
import pandas as pd

# K线域名故障转移链（2026-09-12 实测: web.ifzq 偶发501 JS挑战, 备用域名 ifzq/proxy 均可用）
KLINE_HOSTS = [
    "https://web.ifzq.gtimg.cn/appstock/app/fqkline/get",
    "https://ifzq.gtimg.cn/appstock/app/fqkline/get",
    "https://proxy.finance.qq.com/ifzqgtimg/appstock/app/fqkline/get",
]
# usfqkline 端点链（2026-09-12 17:45 全栈开发实测新增）:
# 美股指数 usDJI/IXIC/INX/NDX 及 .N 后缀部分ETF 在 fqkline 端点只回1行,
# 换 usfqkline 端点 + qfq 参数可回250根全量（道指/纳指/标普/纳指100 实测通过）
USFQ_HOSTS = [
    "https://web.ifzq.gtimg.cn/appstock/app/usfqkline/get",
    "https://ifzq.gtimg.cn/appstock/app/usfqkline/get",
    "https://proxy.finance.qq.com/ifzqgtimg/appstock/app/usfqkline/get",
]
REALTIME_URL = "https://qt.gtimg.cn/q="
HEADERS = {"User-Agent": "Mozilla/5.0", "Referer": "https://gu.qq.com/"}
RAW_COLS = ["date", "open", "close", "high", "low", "volume"]  # 腾讯原始行序


def _fetch_kline_via(hosts: list, code: str, freq: str, count: int,
                     adjust: str, retries: int) -> "pd.DataFrame | None":
    """按给定端点域名链拉K线（fetch_kline 内部实现）。"""
    param = f"{code},{freq},,,{count},{adjust}"
    last_challenge = False
    for i in range(retries):
        url = hosts[i % len(hosts)]  # 轮转域名
        try:
            r = requests.get(url, params={"param": param},
                             headers=HEADERS, timeout=15)
            if r.status_code != 200 or not r.text.strip().startswith("{"):
                last_challenge = True  # JS挑战/风控页, 换域名重试
                time.sleep(0.5 + i)
                continue
            data = r.json().get("data", {})
            if code not in data:
                return None  # v_pv_none_match 等无效情形
            node = data[code]
            key = None
            for k in (f"{adjust}{freq}", freq, f"{freq}{adjust}"):
                if k in node and node[k]:
                    key = k
                    break
            if not key:
                return None
            rows = node[key]
            records = []
            for x in rows:
                row = x[:6] + ([x[6]] if len(x) > 6 else [None])  # 第7列若存在视为amount原始值
                records.append(row)
            df = pd.DataFrame(records, columns=RAW_COLS + ["amount_raw"])
            df["date"] = pd.to_datetime(df["date"])
            for c in RAW_COLS[1:] + ["amount_raw"]:
                df[c] = pd.to_numeric(df[c], errors="coerce")
            return df.dropna(subset=RAW_COLS).sort_values("date").reset_index(drop=True)
        except Exception:
            last_challenge = True
            time.sleep(1 + i)
    if last_challenge:
        print(f"[kline][warn] {code}: 全部域名重试后仍未取得有效响应(疑似风控/限流), 记失败待重跑")
    return None


def fetch_kline(code: str, freq: str = "day", count: int = 250,
                adjust: str = "qfq", retries: int = 3) -> "pd.DataFrame | None":
    """拉取单只标的K线, 返回标准化DataFrame(时间正序); 无效/退市代码返回 None。

    freq: day / week / month ;  adjust: qfq前复权(默认)/空串不复权
    美股后缀必须正确: NASDAQ→.OQ, NYSE→.N, ETF(Arca/AMEX)→.AM（2026-09-12实测,
    早期"接口忽略后缀"结论有误——usBABA.OQ 会失败而 usBABA.N 正常）。
    美股指数与 .N 后缀ETF 行数不足时自动降级到 usfqkline 端点补拉（见 USFQ_HOSTS 注释）。
    主域名遇 501/JS挑战时自动切换备用域名(ifzq.gtimg.cn / proxy.finance.qq.com)。
    """
    df = _fetch_kline_via(KLINE_HOSTS, code, freq, count, adjust, retries)
    if code.startswith("us") and (df is None or len(df) < count):
        df2 = _fetch_kline_via(USFQ_HOSTS, code, freq, count, adjust, retries)
        if df2 is not None and (df is None or len(df2) > len(df)):
            df = df2
    return df


def fetch_realtime(codes: list, retries: int = 3) -> list:
    """批量实时快照(qt.gtimg.cn, 单次请求, GBK解码)。

    返回 list[dict]: key, market, name, price, prev_close, open, volume,
                     pct_chg, high, low, quote_ts, amount_raw
    无效代码自动跳过(不抛异常); 通道口径为"尽力解析", 字段缺失记 None。
    """
    for i in range(retries):
        try:
            r = requests.get(REALTIME_URL + ",".join(codes),
                             headers=HEADERS, timeout=15)
            txt = r.content.decode("gbk", errors="replace")
            out = []
            for line in txt.strip().split(";"):
                line = line.strip()
                if "=" not in line:
                    continue
                key, val = line.split("=", 1)
                key = key.strip().replace("v_", "")
                parts = val.strip('"').split("~")
                if key == "pv_none_match" or len(parts) < 6 or parts[0] in ("1",):
                    if key == "pv_none_match":
                        continue
                ptype = parts[0] if parts else ""
                if ptype == "1":        # A股/指数
                    mkt = "CN"
                elif ptype == "100":    # 港股/指数
                    mkt = "HK"
                elif ptype == "200":    # 美股
                    mkt = "US"
                elif ptype == "310":    # 外汇
                    mkt = "FX"
                else:
                    mkt = "UNKNOWN"

                def f(idx):
                    try:
                        return float(parts[idx])
                    except (IndexError, ValueError):
                        return None

                if mkt == "FX":
                    ts = parts[5] if len(parts) > 5 else None
                    out.append(dict(key=key, market=mkt, name=parts[1],
                                    code=parts[2], price=f(3), prev_close=f(6),
                                    open=f(7), volume=None, pct_chg=None,
                                    high=f(8), low=f(9), quote_ts=ts, amount_raw=None))
                else:
                    ts = None
                    out.append(dict(key=key, market=mkt, name=parts[1],
                                    code=parts[2], price=f(3), prev_close=f(4),
                                    open=f(5), volume=f(6), pct_chg=f(32),
                                    high=f(33), low=f(34), quote_ts=ts,
                                    amount_raw=f(36)))
            return out
        except Exception:
            time.sleep(1 + i)
    return []


def us_realtime_code(kline_code: str) -> str:
    """美股K线码(usAAPL.OQ) → 实时码(usAAPL)。非美股原样返回。"""
    if kline_code.startswith("us") and "." in kline_code:
        return kline_code.split(".")[0]
    return kline_code
