# -*- coding: utf-8 -*-
"""
美股 名称↔代码↔后缀 映射表 + 验证器
======================================
后缀规则（资深量化技术专家实测约定，本模块再验证）:
  K线:   NASDAQ → usXXX.OQ ,  NYSE → usXXX.N ,  AMEX → usXXX.AM(探测)
  实时:  usXXX（无后缀，返回值内含完整后缀代码）

映射表落地 config/us_symbols.json，由 scripts/verify_symbols.py 生成/更新。
"""
import json
import os
import time

from . import tencent_api

CONFIG_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "config")
US_SYMBOLS_JSON = os.path.join(CONFIG_DIR, "us_symbols.json")

# 常用中文名 → 美股代码（无后缀）。后缀由验证器按 NASDAQ/NYSE/AMEX 探测回填。
US_NAME_MAP = {
    "苹果": "AAPL", "微软": "MSFT", "谷歌A": "GOOGL", "谷歌C": "GOOG",
    "亚马逊": "AMZN", "英伟达": "NVDA", "Meta": "META", "特斯拉": "TSLA",
    "阿里巴巴": "BABA", "拼多多": "PDD", "京东": "JD", "百度": "BIDU",
    "网易": "NTES", "腾讯音乐": "TME", "蔚来": "NIO", "小鹏汽车": "XPEV",
    "理想汽车ADR": "LI", "哔哩哔哩": "BILI",
    "AMD": "AMD", "英特尔": "INTC", "美光科技": "MU", "高通": "QCOM",
    "博通": "AVGO", "德州仪器": "TXN", "应用材料": "AMAT", "迈威尔": "MRVL",
    "台积电": "TSM", "阿斯麦": "ASML",
    "摩根大通": "JPM", "高盛": "GS", "美国银行": "BAC", "维萨": "V",
    "沃尔玛": "WMT", "好市多": "COST", "礼来": "LLY", "默沙东": "MRK",
    "埃克森美孚": "XOM", "波音": "BA", "麦当劳": "MCD", "可口可乐": "KO",
    "强生": "JNJ", "宝洁": "PG", "迪士尼": "DIS", "奈飞": "NFLX",
    # 宏观研究员《美股板块+个股观察清单v1》18只中未入主池的12只（2026-09-12 新增）
    "伊顿": "ETN", "纬度控股": "VRT", "GE Vernova": "GEV", "卡特彼勒": "CAT",
    "CoreWeave": "CRWV", "雪佛龙": "CVX", "康菲石油": "COP", "斯伦贝谢": "SLB",
    "星座能源": "CEG", "Vistra": "VST", "Talen Energy": "TLN", "Bloom Energy": "BE",
    # 指数代码表（K线实测通过 2026-09-12）
    "道琼斯工业指数": "DJI", "纳斯达克综合指数": "IXIC",
    "标普500": "INX", "纳斯达克100": "NDX",
}

# 官方交易所归属（映射表按官方后缀维护）
# ⚠️ 2026-09-12 17:40 全栈开发二次实测修正: 腾讯K线接口**不**忽略后缀！
#    usBABA.OQ/ usJPM.OQ 全部失败, usBABA.N/ usJPM.N 正常返回250根 →
#    NYSE 股必须用 .N, NASDAQ 用 .OQ, ETF(Arca/AMEX) 用 .AM（SPY.N 仅回1行, SPY.AM 250根）。
#    早期"忽略后缀"结论系当时批量限流导致的误判, 已推翻。
US_EXCHANGE = {
    "AAPL": "NASDAQ", "MSFT": "NASDAQ", "GOOGL": "NASDAQ", "AMZN": "NASDAQ",
    "NVDA": "NASDAQ", "META": "NASDAQ", "TSLA": "NASDAQ", "PDD": "NASDAQ",
    "JD": "NASDAQ", "BIDU": "NASDAQ", "NTES": "NASDAQ", "AMD": "NASDAQ",
    "INTC": "NASDAQ", "MU": "NASDAQ", "QCOM": "NASDAQ", "AVGO": "NASDAQ",
    "TXN": "NASDAQ", "AMAT": "NASDAQ", "MRVL": "NASDAQ", "ASML": "NASDAQ",
    "LI": "NASDAQ", "COST": "NASDAQ",
    "CRWV": "NASDAQ", "CEG": "NASDAQ", "TLN": "NASDAQ",
    "BABA": "NYSE", "TME": "NYSE", "NIO": "NYSE", "XPEV": "NYSE",
    "TSM": "NYSE", "JPM": "NYSE", "V": "NYSE", "WMT": "NYSE",
    "LLY": "NYSE", "XOM": "NYSE", "GS": "NYSE", "BAC": "NYSE",
    "MRK": "NYSE", "BA": "NYSE",
    "ETN": "NYSE", "VRT": "NYSE", "GEV": "NYSE", "CAT": "NYSE",
    "CVX": "NYSE", "COP": "NYSE", "SLB": "NYSE", "VST": "NYSE", "BE": "NYSE",
}


def probe_us_symbol(symbol: str, name_cn: str = "") -> dict:
    """探测单只美股的后缀与可用性。优先按官方交易所后缀（US_EXCHANGE），失败再依次尝试。"""
    official = US_EXCHANGE.get(symbol)
    order = []
    if official:
        order.append({"NASDAQ": ".OQ", "NYSE": ".N", "AMEX": ".AM"}[official])
    for s in (".OQ", ".N", ".AM"):
        if s not in order:
            order.append(s)
    result = {"symbol": symbol, "name_cn": name_cn, "exchange": official,
              "kline_code": None, "realtime_code": f"us{symbol}",
              "suffix": None, "verified": False,
              "note": "后缀按官方交易所维护(.OQ/.N/.AM,实测严格区分)" if official else None,
              "last_verified": None}
    for suffix in order:
        code = f"us{symbol}{suffix}"
        df = tencent_api.fetch_kline(code, count=5)
        if df is not None and len(df) > 0:
            result.update(kline_code=code, suffix=suffix.lstrip("."),
                          verified=True, last_verified=time.strftime("%Y-%m-%d %H:%M:%S"))
            break
        time.sleep(0.2)
    return result


def build_mapping(candidates: list) -> list:
    """candidates: [(symbol, name_cn), ...] → 验证并返回映射表 list[dict]"""
    table = []
    for sym, name in candidates:
        entry = probe_us_symbol(sym, name)
        table.append(entry)
        status = "OK" if entry["verified"] else "FAIL"
        print(f"[verify] {name:10s} {sym:8s} -> {status} {entry['kline_code'] or ''}")
    return table


def load_mapping() -> list:
    if os.path.exists(US_SYMBOLS_JSON):
        with open(US_SYMBOLS_JSON, encoding="utf-8") as f:
            return json.load(f)
    return []


def kline_code_for(symbol: str, mapping: list = None) -> "str | None":
    """按映射表查K线代码；查不到时按 NASDAQ 优先规则兜底返回 usXXX.OQ。"""
    for e in (mapping or load_mapping()):
        if e["symbol"] == symbol and e["verified"]:
            return e["kline_code"]
    return f"us{symbol}.OQ"
