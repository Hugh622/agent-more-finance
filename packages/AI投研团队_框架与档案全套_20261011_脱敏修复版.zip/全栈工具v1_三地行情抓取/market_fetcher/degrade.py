# -*- coding: utf-8 -*-
"""
降级层框架：官方直连(L1) → 第三方可靠来源(L2) → 检索兜底(L3)
================================================================
设计依据:
  - 用户指示 2026-09-12: 美联储/SEC等官方数据不强求直连官方API，可靠第三方来源
    （权威报纸/传媒）核验可靠即可引用；第三方来源数据统一带「来源+时间戳」。
  - 宏观研究员《官方数据第三方可靠来源清单与核验标准 v1》:
    * 来源分级 S(官方一手)/A/B/C；source 字段 = 「机构-媒体-时间戳」；行级 grade 字段。
    * 第六节: config 配 primary_source + verify_source；传媒抓取失败自动降级人工检索。
  - 本环境实测 (2026-09-12):
    * L1 可达: home.treasury.gov ✅ / fred.stlouisfed.org ✅(偶发慢, 需长超时) /
      sec.gov EDGAR ✅(须带含联系方式的规范UA) / chinamoney.com.cn ✅
    * L2 实测: stooq.com 等第三方行情站均被JS挑战拦 → 本环境L2以「权威传媒检索录入
      登记」+「腾讯授权行情通道」两种形态落地，不硬抓传媒页面(反爬不稳)。
    * L3: config/third_party_records.json 登记簿（检索录入模板强制字段）。

用法:
    from . import degrade
    df, meta = degrade.run_chain(degrade.US_YIELD_CHAIN)
    # meta = {"level": "官方直连", "source": "...-ts", "grade": "S", "degraded": False}
"""
import csv
import io
import json
import os
import time
from datetime import datetime, timedelta

import pandas as pd
import requests

from . import storage

UA_COMPLIANT = "Mozilla/5.0 (research; contact: quant-research-agent@example.com)"
HEAD = {"User-Agent": UA_COMPLIANT}
FRED_URL = "https://fred.stlouisfed.org/graph/fredgraph.csv"
SEC_SUBMISSIONS_URL = "https://data.sec.gov/submissions/CIK{cik10}.json"

CONFIG_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "config")
RECORDS_PATH = os.path.join(CONFIG_DIR, "third_party_records.json")


# ---------------------------------------------------------------- FRED (L1)
def fetch_fred_series(series_id: str, start: str = "2026-01-01",
                      timeout: int = 45, retries: int = 2) -> "pd.DataFrame | None":
    """拉取FRED单序列为宽表(date,value)。偶发慢, 用长超时+重试。"""
    for i in range(retries):
        try:
            r = requests.get(FRED_URL, params={"id": series_id, "cosd": start},
                             headers=HEAD, timeout=timeout)
            if r.status_code != 200 or not r.text.startswith("observation_date"):
                time.sleep(2 + 2 * i)
                continue
            df = pd.read_csv(io.StringIO(r.text))
            df.columns = ["date", "value"]
            df["date"] = pd.to_datetime(df["date"])
            df = df.dropna().sort_values("date")
            df["series_id"] = series_id
            return df
        except Exception:
            time.sleep(2 + 2 * i)
    return None


# 多序列一次拉取（美债降级备用: DGS2/DGS10/DGS30）
FRED_US_YIELD_SERIES = {"2Y": "DGS2", "10Y": "DGS10", "30Y": "DGS30"}


def fetch_fred_us_yields(start: str = "2026-08-01") -> "pd.DataFrame | None":
    frames = []
    for tenor, sid in FRED_US_YIELD_SERIES.items():
        df = fetch_fred_series(sid, start=start)
        if df is not None and len(df):
            df = df.rename(columns={"value": tenor})
            frames.append(df.set_index("date")[tenor])
    if not frames:
        return None
    return pd.concat(frames, axis=1).reset_index().sort_values("date")


# ---------------------------------------------------------------- SEC EDGAR (L1)
def fetch_sec_filings(us_pool_ciks: dict, timeout: int = 20) -> "pd.DataFrame | None":
    """SEC EDGAR 官方直连：抓取美股池公司最近一次 10-K/10-Q/8-K 摘要。
    us_pool_ciks: {"AAPL": {"name_cn": "苹果", "cik": "0000320193"}, ...}
    SEC 合规要求: UA 必须含联系方式；限速 ≤10 req/s。
    """
    rows = []
    for sym, info in us_pool_ciks.items():
        cik = info.get("cik")
        if not cik:
            continue
        try:
            r = requests.get(SEC_SUBMISSIONS_URL.format(cik10=cik.zfill(10)),
                             headers={**HEAD, "Accept": "application/json"},
                             timeout=timeout)
            if r.status_code != 200:
                continue
            j = r.json()
            recent = j.get("filings", {}).get("recent", {})
            forms = recent.get("form", [])
            dates = recent.get("filingDate", [])
            accs = recent.get("accessionNumber", [])
            docs = recent.get("primaryDocument", [])
            picked = {}
            for f_, d_, a_, p_ in zip(forms, dates, accs, docs):
                if f_ in ("10-K", "10-Q", "8-K") and f_ not in picked:
                    picked[f_] = (d_, a_, p_)
                if len(picked) == 3:
                    break
            for f_, (d_, a_, p_) in picked.items():
                rows.append({
                    "symbol": sym, "name_cn": info.get("name_cn", ""), "cik": cik,
                    "form": f_, "filing_date": d_,
                    "accession": a_,
                    "doc_url": f"https://www.sec.gov/Archives/edgar/data/{cik.zfill(10)}/{a_.replace('-', '')}/{p_}",
                })
        except Exception:
            continue
    return pd.DataFrame(rows) if rows else None


# ---------------------------------------------------------------- L2/L3 登记簿
def load_third_party_records(fresh_hours: int = 48) -> "pd.DataFrame | None":
    """读取检索录入登记簿(config/third_party_records.json)中仍在滞后时限内的记录。
    字段强制: series/value/as_of/source_media/source_url/grade/quote_ts/
             entered_at/verifier/cross_check_status
    cross_check_status ∈ verified / single_pending (单源待核24h) / unverified(不入库)
    """
    if not os.path.exists(RECORDS_PATH):
        return None
    try:
        with open(RECORDS_PATH, encoding="utf-8") as f:
            recs = json.load(f).get("records", [])
    except Exception:
        return None
    cutoff = datetime.now() - timedelta(hours=fresh_hours)
    rows = []
    for r in recs:
        if str(r.get("cross_check_status")) == "unverified":
            continue
        try:
            entered = datetime.fromisoformat(str(r.get("entered_at")))
        except Exception:
            continue
        if entered < cutoff:
            continue
        rows.append(r)
    return pd.DataFrame(rows) if rows else None


# ---------------------------------------------------------------- 降级链执行器
def run_chain(steps: list, ts: str = None) -> tuple:
    """按序执行降级链, 返回 (df或payload, meta)。
    steps: [{"name","level","grade","fetch": callable, "validate": fn?, "source": tpl}, ...]
    meta: {"level","source","grade","degraded","attempts":[...]}; 全链失败返回 (None, meta)
    """
    attempts = []
    ts = ts or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    for st in steps:
        try:
            payload = st["fetch"]()
        except Exception as e:
            payload = None
            attempts.append({"step": st["name"], "error": str(e)[:80]})
            continue
        ok = payload is not None
        if ok and st.get("validate"):
            ok = bool(st["validate"](payload))
        attempts.append({"step": st["name"], "ok": ok})
        if ok:
            return payload, {
                "level": st["level"], "grade": st.get("grade", ""),
                "source": storage.stamp(st["source"], ts),
                "degraded": st["name"] != steps[0]["name"],
                "attempts": attempts,
            }
    return None, {"level": "全链失败", "source": None, "grade": None,
                  "degraded": True, "attempts": attempts}
