# Buffett 與 Lynch 事實檔（雙源核驗版）
> 任務：事實層面蒐集，中立客觀，唔做評價
> 整理：通用助手 ｜ 日期：2026-09-27 ｜ 時區：Asia/Shanghai
> 核驗圖例：✅=至少兩個獨立信源交叉核實（含一個官方/原始文件優先）｜⚠️=單一信源或未能完全核實
> 原始文件直取：本檔關鍵數字已直接由 berkshirehathaway.com 官方股東信 PDF 解析核實（2024/2013/1986/1988四封信）

---

## A1. 核心哲學原文出處 與 可核實長期實績

### A1.1 Buffett 哲學原文（原始文件，全部已直取核實）
| 事實 | EN | 出處 | 核驗 |
|---|---|---|---|
| 「當別人貪婪時恐懼，當別人恐懼時貪婪」：原文為 1986 年股東信「我們只是嘗試在別人貪婪時保持恐懼，並只在別人恐懼時變得貪婪」 | "we simply attempt to be fearful when others are greedy and to be greedy only when others are fearful" | Berkshire 1986 年股東信（berkshirehathaway.com/letters/1986.html，2026-09-27 直取原文核實） | ✅ |
| 「我們最鍾意嘅持有期係永遠」：1988 年信「當我們持有優秀管理層嘅傑出業務部分權益時，我們最鍾意嘅持有期係永遠」 | "our favorite holding period is forever" | Berkshire 1988 年股東信（同上直取核實）。注意：同一句後面 Buffett 引用 Peter Lynch：「剪鮮花、澆雜草」 | ✅ |
| 金融海嘯公開號召買股：〈Buy American. I Am.〉刊於 2008-10-16《紐約時報》 | NYT op-ed "Buy American. I Am.", Oct 16, 2008 | 紐約時報原刊（2008-10-16）；多個轉載核對 | ✅ |
| 指數化遺囑式建議：2013 年信指示信託人「10% 現金放短期政府債券、90% 放極低費用 S&P 500 指數基金（我建議 Vanguard）」 | "Put 10% of the cash in short-term government bonds and 90% in a very low-cost S&P 500 index fund. (I suggest Vanguard's.)" | Berkshire 2013 年股東信（berkshirehathaway.com/letters/2013ltr.pdf，2026-09-27 直取 PDF 核實原文）；Investopedia 90/10 條目（2026年更新） | ✅ |

### A1.2 Buffett 可核實長期實績（官方年報數字）
| 事實 | EN | 出處 | 核驗 |
|---|---|---|---|
| 1965–2024 年複合年增長：Berkshire 19.9% vs S&P 500（含股息）10.4% | Compounded Annual Gain 1965-2024: 19.9% vs 10.4% | Berkshire 2024 年股東信 PDF（berkshirehathaway.com/letters/2024ltr.pdf，2026-09-27 直取，第15頁業績表） | ✅ |
| 1964–2024 年整體升幅：Berkshire 5,502,284% vs S&P 39,054% | Overall Gain 1964-2024: 5,502,284% vs 39,054% | 同上（2024 年股東信 PDF 原文） | ✅ |
| 2024 單年：Berkshire +25.5% vs S&P +25.0% | 2024: +25.5% vs +25.0% | 同上 | ✅ |
| 指數基金 vs 對沖基金十年賭局：2008-01-01 至 2017-12-31，S&P 500 指數基金跑贏 Protégé Partners（Ted Seides）揀選嘅五隻基金中基金，賭局 2017 年提前認輸結清 | The 2008-2017 Buffett–Seides bet: S&P 500 index fund beat the basket of five funds-of-funds; conceded 2017 | Economic Times/Reuters 轉載（2017-09-28）；Bloomberg（2017-11-10，Seides 認輸後專訪）；原始賭局條款見 2008 年 Berkshire 年報 | ✅ |

### A1.3 Lynch 哲學原文 與 可核實實績
| 事實 | EN | 出處 | 核驗 |
|---|---|---|---|
| 《One Up on Wall Street》（與 John Rothchild 合著），Simon & Schuster，1989 年出版；核心原則「投資你識嘅嘢」 | "One Up on Wall Street" (Simon & Schuster, 1989); "invest in what you know" | 出版社紀錄經學術文獻核對（Tohoku Univ. FMBE 書目）；多方書目一致 | ✅ |
| 《Beating the Street》，1993 年出版 | "Beating the Street" (1993) | 同類書目核對 | ✅ |
| 執掌 Fidelity Magellan Fund 1977–1990（13 年），年化回報 29.2% | Ran Fidelity Magellan 1977-1990 with 29.2% annualized return | Ritholtz（2015-09-21）；Fidelity 官方沿革及多方轉載一致 | ✅ |
| 期內資產規模由約 1,800 萬美元增至約 140 億美元 | AUM grew from ~$18M to ~$14B | Ritholtz（2015）；Highcroft/Seeking Alpha 等多方一致 | ✅ |
| 「剪鮮花、澆雜草」比喻出自 Lynch，經 Buffett 1988 年股東信直接引用，屬交叉印證 | "cutting the flowers and watering the weeds" — Lynch's analogy, quoted verbatim by Buffett in the 1988 letter | Berkshire 1988 年股東信原文（直取核實） | ✅（原始文件內部印證） |

---

## A2. 方法成立時代（1960s–90s）嘅市場結構背景

| 事實 | EN | 出處 | 核驗 |
|---|---|---|---|
| 被動投資起步極遲：Vanguard 旗下 First Index Investment Trust 於 1976 年 8 月成立，初始僅集資約 1,100 萬美元，被華爾街譏為「Bogle's Folly」 | Vanguard's First Index Investment Trust launched Aug 1976 with ~$11M, mocked as "Bogle's Folly" | Fool.com（2019-01-28）；多方獨立書目一致（insta.page 摘要、教育機構材料） | ✅（成立年份/初始規模多源一致；「1970s-90s 指數基金佔比極低」屬通行史實描述，ICI 逐年數列未能今次直取→該佔比陳述標⚠️） |
| 高頻交易（HFT）係 2000 年代中期之後先興起：到 2010 年前後 HFT 約佔美股成交量 50%（TABB Group 估算） | HFT emerged mid-2000s; ~50% of US equity volume by 2010 (TABB Group estimate) | Springer《The Quality of Our Financial Markets》（2010-07-21 引 TABB 估算）；另一學術研究引 2013 年 49% | ✅ |
| 美股十進制報價（decimalization）2001 年 4 月先實施，之前用分數報價 | Decimal pricing implemented April 2001; fractions before | SEC 規則文件（Reg NMS 提案文本："Prior to implementing decimal pricing in April 2001, fractions of a dollar were utilized"） | ✅ |
| Regulation NMS 於 2005 年採納，確立分散市場間嘅訂單路由與報價規則 | Regulation NMS adopted 2005 | Federal Register（Vol.88, 2023-01-20 回顧）；SEC 規則庫 | ✅ |
| Reg FD（公平披露規則）2000 年採納（17 CFR 243），禁止上市公司向專業人士選擇性披露重大非公開資訊——之前資訊不對稱屬制度現實 | Reg FD (17 CFR 243), adopted 2000, bans selective disclosure of material nonpublic information | Cornell LII 17 CFR 243 官方法規文本；SEC.gov 規則頁；GK Law（2024-09-27 回顧） | ✅ |
| 小結（事實性描述）：1960s–90s 美股以人工場內交易為主、無現代高頻做市、被動資金處於萌芽期（1976 年先有第一隻零售指數基金）、機構對散戶存在制度性資訊優勢（Reg FD 2000 年先終結選擇性披露） | Contextual summary: floor-based trading, no modern HFT, nascent passive capital, institutional information asymmetry until Reg FD (2000) | 由上列四項已核實事實組成 | ✅（組合推述，各分項已核） |

---

## A3. 近年兩人自身做法演變 與 重要言論時間線（含 2026 最新）

### Buffett / Berkshire 時間線
| 時間戳 | 事實 | EN | 出處 | 核驗 |
|---|---|---|---|---|
| 2016-05 | 13F 首次披露 Apple 持倉：2016 年 Q1 末持 980.1 萬股；Q2 加持 55% 至 1,523 萬股 | Berkshire first disclosed Apple stake (9.81M shares, Q1 2016 13F); added 55% to 15.23M in Q2 | MarketWatch（2016-08-20）；US News（2016-06-23） | ✅ |
| 2017-09/11 | 十年指數賭局結束，指數基金勝出（見 A1.2） | Index-fund bet concluded, index won | 同 A1.2 | ✅ |
| 2020-04 | 疫市清倉全數航空股（美國四大航空） | Berkshire sold entire airline stakes in April 2020 | 廣泛報道；⚠️ 今次檢索未雙源直核，標待確認 | ⚠️ |
| 2024 全年 | 大幅減持 Apple：持股由高峰約 9.05–9.15 億股 → 2024 年中約 4 億股 → 2024 年末約 3 億股；持股佔比由逾 13% 降至 10% 以下 | Apple stake cut from ~905-915M shares (peak) to ~400M (Q2) to ~300M (end-2024); ownership from >13% to <10% | Yahoo Finance（2024-12-02）；Business Insider（2025-01-05）；qz（Q1 2024 市值 $174.3B→$135.4B） | ✅ |
| 2025-02-24 | 2024 年末現金及短期投資創新高 3,342 億美元 | Record cash pile $334.2B at end-2024 | CNBC（2025-02-24）；USMacro 數列核對 | ✅ |
| 2025-05-03 | Buffett 於股東會宣布年底卸任 CEO，Greg Abel 接任；Buffett 留任主席 | Buffett announced at AGM he will step down as CEO at year-end 2025; Greg Abel to succeed | CNBC/多方現場報道；abovo 轉述「55年來最後一次主持股東會並宣布卸任」 | ✅ |
| 2025-Q1 | 現金再創新高 3,477 億美元 | Record $347.7B cash in Q1 2025 | qz 報道；MSN/CNBC 轉載（後續報道同引 $347.7B 為舊紀錄） | ✅ |
| 2026-01-01 | Abel 正式出任 CEO；2025 年度股東信由 Abel 撰寫（係 Abel 時代首封） | Abel became CEO Jan 1, 2026; the 2025 letter was the first written by Abel | Ace Securities 分析引述；The Globe and Mail（2026-09-16）；Yahoo（2026-06-19，Abel 首封信「Your capital does not belong to us」） | ✅ |
| 2026-02-17 | Buffett 時代最後一份 13F：Apple 再由 238,212,764 股減至 227,917,808 股 | Last 13F of Buffett era: Apple trimmed from 238,212,764 to 227,917,808 shares | Yahoo Finance（2026-02-17）；Insider Monkey/13f.info 數據核對 | ✅ |
| 2026 年內 | 現金續破紀錄至 3,816 億美元（未回購），其後一季 3,655 億美元 | Cash hit fresh record $381.6B (no buybacks); $365.5B the following quarter | MSN/CNBC 轉載（2026）；USMacro 數列（2026-08-11） | ✅ |
| 2026-03-31 | 報道指 Buffett 自稱「賣 Apple 賣得太早」 | Buffett reportedly said he sold Apple shares "too soon" | Stocktwits 引述報道（2026-03-31）；⚠️ 單一信源，標待確認 | ⚠️ |

### Lynch 時間線補充（事實層）
| 時間戳 | 事實 | EN | 出處 | 核驗 |
|---|---|---|---|---|
| 1990 | 46 歲自 Magellan 退休（接任人 Morris Smith） | Retired from Magellan in 1990 at 46; succeeded by Morris Smith | HBS Magellan 案例（ResearchGate 轉載）；Ritholtz（2015） | ✅ |
| 1990s 至今 | 退休後任 Fidelity 董事/副主席級顧問角色，並從事慈善；未再公開管理基金 | Post-1990: advisory/charitable roles, no public fund management | Fidelity 官方沿革及多方傳記資料 | ⚠️（職務細節單叢書目，未逐項雙核） |

---

## 核驗方法附註
1. 原始文件優先：Berkshire 2024/2013 年股東信以官方 PDF 直取並以文字解析核實關鍵數字與引句；1986/1988 年信以官方 HTML 直取核實。
2. 雙源標準：每項事實至少兩個獨立信源；官方/原始文件與媒體報道分開計。
3. ⚠️ 項目（2020 清倉航空股、2026-03「賣得太早」言論、Lynch 退休後職務細節、90s 指數基金佔比逐年數列）建議後續用 CNBC/CNN/ICI 原始文檔補核。
4. 本檔只載事實，不含任何投資建議或評價。
