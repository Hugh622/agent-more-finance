# Ahju（阿豬）Q&A 精華筆記
**影片長度：** 10:34 ｜ **共 7 條問題** ｜ **格式：** 港式繁體＋英文對照，附時間軸

---

## Q1️⃣ 短線／中線／長線點分配？｜Swing / Position / Long-term Allocation
⏱ 00:02 – 01:21

**提問重點：** Portfolio 入面 Swing Trade、Position Trade 同 Long-term Hold 應該點分配比例？

**Ahju 核心觀點：**
- 完全睇個人，**冇 model answer**。每個人嘅財務目標、風險承受能力、trading 能力都唔同（00:12–00:29）
- 問人哋嘅分配冇乜意思：就算 hypothetically 係「六成長線、三成短炒、一成中線」，呢個資訊對任何人都**完全冇價值**（00:29–00:42）
- 唔明白人哋嘅屋企狀況、財務狀況、健康狀況，照抄人哋嘅 allocation 隨時仲差過冇聽過（00:42–00:54）
- 正確做法：先定義自己嘅財務目標（想喺某個年紀達到咩財務狀況），再倒推需要幾多長線、幾多短炒、短炒預期回報係幾多，先 set 到適合自己嘅 allocation（00:54–01:21）

**🔑 金句／實用原則：**
> 「六成長線、三成短炒、一成中線——呢個資訊對任何人都完全冇價值。」
> "60% long-term, 30% swing, 10% position — that information should be worthless to anyone else."

> 「Allocation 係由你嘅財務目標倒推出嚟，唔係抄人。」
> "Your allocation is derived backwards from YOUR financial goals, not copied from others."

---

## Q2️⃣ 長線投資點建立？Buy the Dip vs DCA
⏱ 01:21 – 02:57

**提問重點：** 長線應該點建立？之前 Ahju 話可以跌到 50 天線再買，但書上話 buy the dip 會錯過大部分升幅，點睇？

**Ahju 核心觀點：**
- 冇絕對答案：**冇人知道個市場幾時見底**（01:47–01:55）。接受呢個事實，就會明白唔同方法各有好壞
- Buy the dip 嘅代價：可能 miss out 一啲機會（01:42–01:47）
- **佢自己嘅做法**（聲明：唔係投資意見）：
  - 類似月供，定期擠錢落長線（02:20–02:28）
  - 跌到 200 天線／明顯超賣時，額外加碼（02:28–02:35）
  - 該年 trading 賺大錢，allocate 部分利潤去長線（02:35–02:39）
- 長線嗰邊**唔想 time 個市場**——trading 已經夠晒靠眼光，長線就求簡單：有錢就擠、定期擠，20–40 年後分別唔大（02:39–02:57）

**🔑 金句／實用原則：**
> 「冇人知道個市場幾時見底。你接受咗呢個事實，就會明白點解冇絕對答案。」
> "Nobody knows when the market bottoms. Accept that fact, and you'll see why there's no absolute answer."

> 「長線投資我唔想 time 市——trading 嗰邊已經係靠眼光，長線求簡單。」
> "For long-term investing I don't want to time the market — trading already requires my judgement; long-term should stay simple."

---

## Q3️⃣ Whipsaw 市況突發事件：會唔會即刻追入／Gap Up 追貨？
⏱ 02:57 – 04:39

**提問重點：** 突發事件（打仗數據／加息預期放鴿／AI narrative 改變如 NVDA 財報）令市場由 panic 轉 neutral/aggressive，position light 嘅時候會唔會即刻搵 setup 買貨、追返之前冇買到嘅 breakout、或者 RR 由 2.5 跌到 1.5 都照追？

**Ahju 核心觀點：**
- 而家個市資金喺板塊之間跳來跳去、一日話加息一日話唔加息——呢種 **whipsaw 環境反而唔需要做咁多交易**（03:33–04:03）
- 唔需要 outsmart 個 market，唔使每個細郁動、每個板塊轉移都 capture 到（04:03–04:11）
- Whipsaw 環境下 breakout 本身已經難：突破代表升咗一段時間先買，已經唔着數；**再 gap up 先追就更加唔抵**（04:11–04:30）
- 結論：呢種環境少做 breakout、**唔會 gap up 追**，exposure 唔會特別進取（04:30–04:39）

**🔑 金句／實用原則：**
> 「Whipsaw 市反而唔需要做咁多交易，唔好以為每個板塊轉移都要 capture 到。」
> "In a whipsaw market you actually need FEWER trades — don't try to capture every sector rotation."

> 「Breakout 本身已經升咗一段先買，唔着數；gap up 先追就更加唔抵。」
> "Buying a breakout means paying up after a run — chasing a gap-up on top of that is even worse value."

---

## Q4️⃣ High Tight Flag Setup 三問
⏱ 04:39 – 05:56

**提問重點：** ①盤中突破 flag 係咪即刻買？②盤中買咗、收盤後發現成交量低過 avg vol，會唔會平倉？③High tight flag 係咪特定市況先做？

**Ahju 核心觀點：**
- **③先答：會，high tight flag 唔係任何時候都做，喺個市好強嗰時先做**（04:56–05:01）
- 原因：high tight flag 代表隻股已 breakout、短時間升咗唔少，再做一至兩個禮拜 consolidation 再突破——嗰刻隻股已經 extended（05:01–05:18）
- 市場好旺、人人揸唔夠貨、有強 narrative → 有機會繼續升；但市弱／whipsaw／冇明顯 trend → **失敗機會高啲**（05:18–05:35）
- ①市強時，盤中突破就會買（05:35–05:41）
- ②收市後發現成交低過平均，真係麻麻哋、會懷疑——但要睇情況，唔可以一概而論（05:41–05:56）

**🔑 金句／實用原則：**
> 「High tight flag 唔係任何時候都做——喺個市好強嗰時先做。」
> "High tight flag is NOT for all conditions — only trade it in a very strong market."

> 「股票已 extended 仲可以再升，靠嘅係市場好旺＋強 narrative；市弱就失敗率高啲。」
> "The stock is already extended; it keeps rising only when the market is hot and the narrative is strong. In a weak market, failure rate rises."

---

## Q5️⃣ 日元干預對股市嘅影響同交易機會
⏱ 05:56 – 07:43

**提問重點：** 點衡量日元升跌對股市嘅影響？日元一有動作成個市好似地圖炮咁，有冇策略可以搵到交易機會？

**Ahju 核心觀點：**
- 日元升跌平時由經濟、息差等「好悶」因素主導；最近變成 focus 係因為**政府干預**——而且今次唔止日本政府，仲加埋美國（06:06–06:38）
- **歷史對照（相似度好高）：**
  - 2024 年：4 月日元約 160 干預 → 失敗；幾個月後 7 月約 162 再嚟次更大，加埋美國幫手（06:53–07:11）
  - 2026 年：5 月自己干預 → 失敗；兩個月後 7 月再嚟次勁啲，今次又係加埋美國（07:11–07:21）
- 交易機會：反應快絕對有——**Trade USDJPY 係最直接、最 pure 嘅 play**（07:21–07:30）
- Secondary play：日股之前受惠日元貶值，調返轉，**日元升 → 日股受壓**（07:30–07:43）

**🔑 金句／實用原則：**
> 「2024 年 4 月/7 月同 2026 年 5 月/7 月，劇本幾乎一樣：第一次干預失敗，幾個月後加碼再嚟。反應快就 trade USDJPY——最 pure 嘅 play。」
> "The 2024 (Apr/Jul) and 2026 (May/Jul) intervention playbook is nearly identical: first attempt fails, then a bigger one months later. If you're fast, trade USDJPY — the purest play."

> 「日股係 secondary play：日元升，日股受壓。」
> "Japanese stocks are the secondary play: stronger yen = pressure on Nikkei."

---

## Q6️⃣ MPF 點計入資產配置？
⏱ 07:43 – 08:33

**提問重點：** 坊間理論係唔同年齡配唔同比嘅股票債券，MPF 應該計唔計？以股票基金為主嘅 MPF 應該當股票 % 計？60 止先攞得呢個限制有冇影響？

**Ahju 核心觀點：**
- 對佢嚟講**冇影響**：MPF 係基金，ETF 又係基金（08:01–08:05）
- 有啲 MPF 投資美股 → 就有美股 exposure；同 ETF 經濟上基本一模一樣，分別只係**費用貴少少**同**60 歲先攞得返**（08:05–08:22）
- 做長線資產配置，佢本來打算都係 60 歲後先攞，所以冇分別——**MPF 買咗股票，就當埋股票計**（08:22–08:33）

**🔑 金句／實用原則：**
> 「MPF 係基金，ETF 又係基金——經濟上基本一模一樣。MPF 嗰啲股票，我當埋股票計。」
> "An MPF is a fund, an ETF is a fund — economically identical. I count my MPF stock funds as stocks, plain and simple."

---

## Q7️⃣ IPO Lock Up Expiry 會唔會影響入場？
⏱ 08:33 – 10:16

**提問重點：** 某太空股 9 月 8 號突破，但 9 月 9 號 lock up expiry（約 319 million 股可賣出），會唔會因此唔 enter 個 trade？

**Ahju 核心觀點：**
- **會。** 佢會因為 IPO lock up expiry 而唔做一啲交易，**尤其係 expiry 之前隻股好似被人推咗上去噉**（08:48–08:57）
- 細市值股（< USD 1 billion）喺 lock up expiry 前一兩個月，唔知點解就有消息出嚟、炒起，好似好神奇——**呢啲 suspicious，睇得好緊，可能唔做**（09:15–09:35）
- 對照：美國超大公司都有 lock up，但 founder/CEO 唔似等錢使（09:35–09:54）
- 視乎規模：319 million 股唔細，但對超級藍籌可能只係幾日成交、或佔公司單位數 %——**呢類 expiry 就唔會咁介意**；反而好大嘅 lock up 就避一避（09:54–10:16）

**🔑 金句／實用原則：**
> 「Expiry 前被炒起嘅細市值股，好神奇咁有消息出嚟——suspicious，我會避。」
> "Small caps getting mysteriously pumped ahead of lock-up expiry? Suspicious. I'd stay away."

> 「Lock up 影響睇規模：幾日成交量／單位數 % 嘅 expiry 唔使理；巨型 expiry 就避一避。」
> "Scale matters: an expiry worth a few days of volume or single-digit % of the company is noise; a massive one, avoid it."

---

## 📌 全場精華 takeaway 一覽

| # | 主題 | 一句話原則 |
|---|------|-----------|
| 1 | 倉位分配 | 冇標準答案，由自己財務目標倒推，唔好抄人 |
| 2 | 長線建立 | 冇人知幾時見底 → 定期供＋超賣加碼，長線唔 time 市 |
| 3 | Whipsaw 市 | 減少交易、唔好 outsmart 市場、一定唔追 gap up |
| 4 | High Tight Flag | 只喺強市做；盤中突破即刻買；縮量要懷疑 |
| 5 | 日元干預 | 劇本重演，USDJPY 係 purest play；日元升→日股受壓 |
| 6 | MPF | MPF 當股票計，同 ETF 無分別 |
| 7 | Lock Up Expiry | Expiry 前被炒起嘅細市值股要避；影響睇佔比同成交量 |

---
*本筆記根據影片字幕整理，時間軸對應原片。內容為 Ahju 個人分享，唔構成投資意見。*
