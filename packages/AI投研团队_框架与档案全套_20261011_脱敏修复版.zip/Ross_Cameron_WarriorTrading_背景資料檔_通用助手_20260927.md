# Ross Cameron（Warrior Trading 創始人）背景資料檔
**任務：** 客觀事實檔——只做事實層面，唔做策略評價｜**整理：** 通用助手 ｜ 2026-09-27（香港時間 17:15–17:40 檢索）
**核驗標記：** ✅＝至少兩個獨立信源交叉核實；⚠️＝單一信源或當事人自述，未能獨立核實
**格式：** 繁中港式＋英文對照

---

## 一、真人履歷與小帳戶挑戰真實記錄

### 1.1 個人背景
| 事實 | 內容 | 信源 | 標記 |
|---|---|---|---|
| 出生／學歷 | 佛蒙特州（Vermont）人，2009年取得 Vermont College 學士學位 | billionsuccess.com 專訪（自述） | ⚠️自述 |
| 居住地 | 麻省 Berkshire County（與其公司所在地 Great Barrington 同區） | 同上＋FTC訴狀（公司位於Great Barrington, Mass.） | ✅ |
| 創業時間線 | 2012年創Warrior Trading（初為博客，前身名 Day Trade Warrior）；2013年1月開設YouTube頻道；2014年推出首個付費產品（即市聊天室chat room） | speedtrader.com（2016-06-08）；billionsuccess.com 專訪 | ✅ |
| 自稱身份 | 「full-time day trader」、YouTube訂閱逾100萬 | billionsuccess.com；YouTube頻道描述（檢索日2026-09-27） | ✅（訂閱數為檢索日快照） |

### 1.2 小帳戶挑戰（Small Account Challenge）時間線
> ⚠️ 以下全部屬**當事人自述或公司聲稱**，本次檢索未能找到任何獨立第三方審計報告原件；「audited / verified」一詞由本人及公司使用，審計機構身份未見公開文件。

| 時點 | 自述內容 | 信源 | 標記 |
|---|---|---|---|
| 2017-01 | 自稱存入 $583.15 開展挑戰（「In January of 2017, when I funded an account with $583.15… I knew I would want to have my performance from this challenge audited」） | billionsuccess.com 專訪；FTC訴狀§38引述其2020-12-15 webinar逐字稿 | ✅（有兩個信源記載此**自述**；但帳戶本身未獨立核實） |
| 45日後 | 自稱45日內由 $583.15 增至超過 $100,000（廣告語："$583.15 into over $100,000 in 45 days — results not typical"） | FTC訴狀§38引述之廣告及webinar | ⚠️自述（見FTC訴狀原文） |
| 2019 | 自稱帳戶突破 $1,000,000 | billionsuccess.com 專訪 | ⚠️自述 |
| 2022 | 自稱帳戶突破 $10,000,000（專訪稱「audited and verified trading profits」） | billionsuccess.com 專訪 | ⚠️自述；審計方未核實 |
| 現時宣傳口徑 | YouTube頻道描述稱「turned $583.15 into over $18 million day trading」（明示 results NOT typical） | YouTube頻道描述（檢索日2026-09-27快照） | ⚠️自述 |

**⚠️ 時間線差異註記：** 網絡流傳另有一版本稱挑戰始於2013年（$583.15起家）；但FTC訴狀引述佢本人2020年12月webinar逐字稿明言「2017年1月」開始該挑戰。兩個口徑並存，未能裁定孰是孰非，使用者引用時應註明出處版本。｜ Note: a widely circulated version dates the challenge to 2013, while the FTC complaint quotes Cameron himself (Dec 15, 2020 webinar) dating it to January 2017. Both versions coexist; cite the source version when quoting.

**✅ 可核實事實框架：** 訴訟文件（美國聯邦法院 D. Mass. Case No. 3:22-cv-30048，2022-04-19存檔）確認「$583挑戰」廣告宣傳確實存在並成為監管審查對象；FTC唔係質疑佢帳戶數字真假為主要爭點，而係指其營銷令消費者誤以為可以複製該回報。

---

## 二、Warrior Trading 商業模式與利益關係

### 2.1 產品與定價（FTC訴狀 §72–73，✅＋官方網站⚠️）
- **Warrior Starter**：$997／30日會籍；30日後**自動續訂** $197／月，除非取消。（FTC訴狀 §72）
- **Warrior Pro**：$4,297／90日會籍；到期前10個工作日**自動續訂**並扣卡，除非取消。（FTC訴狀 §73）
- 產品線：教育課程、即市聊天室（chat room）、直播代操展示（live trading）、模擬器（simulator）、股票掃描器、免費webinar導流。（FTC訴狀 §22–26＋官方網站）
- 英文對照：*Warrior Starter $997/30 days auto-renewing at $197/month; Warrior Pro $4,297/90 days auto-renewing — per FTC Complaint ¶¶72–73; revenue also from courses, chat room, live trading streams, simulator and scanners.*

### 2.2 收入規模與利益結構
| 事實 | 內容 | 信源 | 標記 |
|---|---|---|---|
| 收入規模 | 2018年1月至2021年3月，三被告喺Day-Trading Programs銷售中產生「數以千萬計美元」（tens of millions of dollars）收入 | FTC訴狀 §25 | ✅（訴狀＋FTC新聞稿） |
| 利益關係 | 收入主要來自賣課程俾散戶，而非其本人交易利潤；FTC指其營銷將「講師自己嘅極端結果」包裝成「普通學員可達致嘅結果」 | FTC訴狀 §27–37（earnings claims條款） | ✅（訴狀指控本身為可核實文件；注意係指控非裁決事實） |
| 券商回佣結構 | Warrior引導學員使用指定broker-dealer，學員可享折扣佣金以「賺返課程費」 | FTC訴狀 §84 | ✅ |
| 100K Club | 學員自願提交券商月結單驗證「賺逾10萬美元」會籍；Cameron本人喺webinar承認「唔知道全部學員嘅成功率，因為我哋無權限睇佢哋帳戶」 | FTC訴狀 §66–67（引述其2020-12-15 webinar逐字稿） | ✅ |

> **利益關係一句話（事實層面）：** 佢主要收入來源係教學生意而非自營交易；「展示交易成績」同時係佢嘅營銷素材——兩者天然綁定，呢個結構係FTC案件嘅核心背景。｜ *His primary revenue comes from selling education, not from his own trading; his displayed trading results double as marketing assets — the structure at the heart of the FTC case.*

---

## 三、監管爭議

### 3.1 FTC 案件（✅ 可核實核心）
| 項目 | 事實 | 信源 |
|---|---|---|
| 案件 | *FTC v. Warrior Trading, Inc., Warrior Operating, Inc., and Ross Cameron*, Case No. 3:22-cv-30048（美國麻省聯邦地區法院西區分院） | FTC案件頁；訴狀首頁 |
| 立案 | 2022-04-19 提交訴狀：違反 FTC Act §5(a) 及 Telemarketing Sales Rule（欺騙性收益宣稱、電訊營銷失實陳述） | FTC訴狀（PDF原件已存本檔同目錄核驗） |
| 和解 | 同日達成 Stipulated Order：支付 **$3,000,000** 用作消費者退款；**禁止**再作出無根據嘅賺錢宣稱 | FTC新聞稿（2022-04-19）＋JDSupra／Cozen O'Connor法律分析（2022-04下旬）＝雙源 |
| 退款執行 | 2023-01-10 FTC公佈：向 **20,402名** 消費者合共退回 **逾$2.9 million** | FTC新聞稿（2023-01-10） |
| 訴狀內學員數據 | ①自家simulator數據（2020-11至2021-03）：**74%帳戶蝕錢，僅10%賺多過$90**（§82）；②FTC調查中取得嘅指定券商交易紀錄（2018-05至2021-05）：**絕大多數學員「冇賺或蝕錢」**（§85） | FTC訴狀 §82、§85 |
| 訴狀引用嘅學術背景 | 加州大學教授研究台灣（中國台灣地區）證交所1992–2006年37億筆交易：僅9.81%成交量嚟自「持續獲利」交易者、單日持續獲利者不足3%（§18引述Linnainmaa等） | FTC訴狀 §18 |
| 和解性質 | 和解令屬民事救濟；訴狀指控唔等同法院裁定嘅事實認定，被告一方係以同意令方式解決（無陪審團裁決） | FTC案件頁＋法律界通行理解 |

### 3.2 「麻省證券監管機構行動」求證結果（⚠️ 待確認）
- 管理員提及「2022年麻省證券監管機構行動」。**本次檢索可核實嘅2022年行動係聯邦貿易委員會（FTC）訴訟**——案件正正喺**麻省聯邦法院**（D. Mass.）提出，公司亦位於麻省，可能係「麻省行動」印象嘅來源。
- 網上另有零星說法指麻省州級證券監管機構（Massachusetts Securities Division, Secretary Galvin）曾於2021年對Warrior Trading提出行政投訴（無註冊投資顧問資格等）；**本次四輪檢索（含官方與新聞源）均未能取得該投訴原文或兩個獨立信源交叉確認，故僅列為未經核實線索，唔納入事實結論。**｜ *A rumored 2021 Massachusetts Securities Division administrative complaint could NOT be verified in this research pass; treated as unconfirmed lead only. The verified 2022 action is the federal FTC suit filed in the District of Massachusetts.*

---

## 四、本人公開承認嘅失敗經歷

以下均為Cameron喺**自己公司旗下面向公眾嘅渠道**（warriortradingnews.com 官方新聞站文章〈How I Became a Profitable Day Trader〉，2024-05-22，及官方『Lessons on Day Trading Success & Failure』專頁）自述內容——⚠️屬自述但出自本人公開發表，方向上對佢不利（承認挫敗），可信度相對高：

| 階段 | 自述內容（原文撮譯） |
|---|---|
| 第一年 | 「-beginner's luck-」賺咗約 **$30,000** |
| 第二年 | **蝕晒成 $30,000**，陷入**嚴重信用卡債**（serious credit card debt） |
| 轉捩點 | 8月一次巨額虧損令佢覆盤全部交易、收緊紀律、只做策略內setup |
| 之後 | 帳戶升至 **$50,000** 後，**單日單一交易蝕 $25,000**；再重建至 $100,000 |
| 一貫口徑 | 官方免責聲明及webinar逐字稿（FTC訴狀§66引述）：「my results are not typical… the majority of traders out there will lose money」 |

- 英文對照：*"My first year showed some beginner's luck — about $30,000. The next year I lost $30,000 and ended up in serious credit card debt… I grew my account to $50,000 and then had a horrible day, losing $25,000 in one trade."*（warriortradingnews.com, 2024-05-22）
- 額外核實點：FTC訴狀引述佢本人承認（§66）：「我哋唔知道學員整體成功率」——與「學員勝率無官方全面統計、只有自願驗證樣本（100K Club）」此一事實一致。✅

---

## 五、信源清單（含檢索時間戳）
| # | 信源 | 性質 | 檢索時間 |
|---|---|---|---|
| 1 | FTC案件頁 ftc.gov/legal-library/browse/cases-proceedings/2023198-warrior-trading-inc-ftc-v（含訴狀PDF、Stipulated Order、Final Order） | 官方 | 2026-09-27 17:22 HKT |
| 2 | FTC新聞稿 2022-04-19〈FTC Cracks Down on Warrior Trading…〉 | 官方 | 同上 |
| 3 | FTC新聞稿 2023-01-10〈FTC Returns More Than $2.9 Million…〉 | 官方 | 同上 |
| 4 | FTC訴狀PDF（Case 3:22-cv-30048, Doc 1, filed 04/19/22, 36頁）原文解析 | 官方文件 | 同上（全文已存檔） |
| 5 | JDSupra／Cozen O'Connor〈FTC Fines Warrior Trading for Misleading Day-Trading Customers〉 | 法律分析 | 2026-09-27 17:24 HKT |
| 6 | billionsuccess.com〈Interview with Warrior Trading Founder Ross Cameron〉 | 當事人專訪（自述） | 2026-09-27 17:25 HKT |
| 7 | warriortradingnews.com〈How I Became a Profitable Day Trader〉2024-05-22 | 當事人官方渠道（自述） | 2026-09-27 17:30 HKT |
| 8 | speedtrader.com〈Ross Cameron of Warrior Trading – 5 Trading Lessons〉2016-06-08 | 第三方媒體 | 同上 |
| 9 | YouTube頻道「Ross Cameron - Warrior Trading」描述頁 | 當事人官方渠道（自述） | 檢索日快照 |
| 10 | mlexwatch.com FTCWatch〈Warrior Trading to pay $3 million over phony money-making claims〉 | 第三方行業媒體（標題級核實） | 同上 |

**檢索限制聲明：** 本環境搜尋引擎對2021年州級監管線索召回率極差（多輪查詢無果），Google/Bing直連受限；如需補核麻省州級行動，建議日後以 PacerMonitor（聯邦案卷）＋ sec.state.ma.us（州證券部門公告庫）定向查證。
